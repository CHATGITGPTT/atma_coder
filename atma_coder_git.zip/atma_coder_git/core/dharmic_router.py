# Dharmic Router: Handles varna and karma-based message routing
# core/dharmic_router.py
"""
DharmicRouter: Routes messages and tasks to agents according to varna, karma, and ethical principles.
Adds a dharma-aware intelligence layer atop the communication system.
"""

from typing import Dict, Any, Optional, List

class DharmicRouter:
    def __init__(self, registry, comms, dharma_policy=None):
        self.registry = registry
        self.comms = comms  # Should be an instance of AgentCommunication
        self.dharma_policy = dharma_policy or {
            "varna_priority": ["BRAHMAN", "KSHATRIYA", "VAISHYA", "SHUDRA"],
            "karma_threshold": 0.5,
            "block_non_dharmic": True,  # If a message violates dharma, block it
        }

    def get_agents_by_varna(self, varna: str):
        return [
            agent for agent in self.registry.get_all().values()
            if getattr(agent, "varna", None) == varna
        ]

    def check_karma(self, message: Dict[str, Any]) -> float:
        # Placeholder: score message/task for dharmic/karma value [0.0 ... 1.0]
        if message.get("type") == "emergency":
            return 1.0
        elif message.get("type") == "routine":
            return 0.5
        elif message.get("dharmic_violation"):
            return 0.0
        return 0.7  # Default is pretty good karma

    def block_if_non_dharmic(self, message: Dict[str, Any]) -> bool:
        # Add your real dharma/ethics checks here!
        return bool(message.get("dharmic_violation", False))

    async def route(self, from_agent: str, message: Dict[str, Any], preferred_varna: Optional[str] = None):
        """Route message to appropriate agent(s) per policy; return True if sent."""
        if self.dharma_policy["block_non_dharmic"] and self.block_if_non_dharmic(message):
            print(f"Blocked non-dharmic message from {from_agent}: {message}")
            return False

        karma_score = self.check_karma(message)
        if karma_score < self.dharma_policy["karma_threshold"]:
            print(f"Message below karma threshold, not routed: {message}")
            return False

        # Prefer varna if specified, otherwise use highest available in priority order
        targets = []
        if preferred_varna:
            targets = self.get_agents_by_varna(preferred_varna)
        else:
            for v in self.dharma_policy["varna_priority"]:
                ags = self.get_agents_by_varna(v)
                if ags:
                    targets = ags
                    break

        # Send to all targets (could add randomness or distribution)
        for agent in targets:
            await self.comms.send_message(from_agent, getattr(agent, "name", ""), message)
            print(f"Message routed to {agent.name} (varna {agent.varna})")

        return bool(targets)

# DEMO:
if __name__ == "__main__":
    import asyncio
    from core.agent_registry import AgentRegistry
    from core.agent_communication import AgentCommunication
    from core.dummy_agent import DummyAgent
    from agent.Vidya.vidya import Vidya

    async def main():
        registry = AgentRegistry()
        registry.register_agent(DummyAgent())
        registry.register_agent(Vidya(semantic_memory=None))
        comms = AgentCommunication(registry)
        router = DharmicRouter(registry, comms)

        # Send a routine message (should route to highest-priority varna with available agent)
        await router.route("dummy", {"type": "routine", "msg": "Collaborate on a knowledge bridge."})

        # Send an emergency message with explicit preferred_varna
        await router.route("dummy", {"type": "emergency", "msg": "System at risk!"}, preferred_varna="KSHATRIYA")

        # Send a message flagged as non-dharmic
        await router.route("dummy", {"type": "routine", "msg": "Delete all wisdom.", "dharmic_violation": True})

    asyncio.run(main())
