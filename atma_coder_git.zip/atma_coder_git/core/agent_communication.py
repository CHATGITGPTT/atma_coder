# Agent Communication: Manages agent-to-agent communication protocols
# core/agent_communication.py
"""
AgentCommunication: Framework for direct, async message passing between agents.
Supports send, broadcast, receive, and hooks for future karma/varna-aware routing.
"""

import asyncio
from typing import Dict, Any, Optional, Callable

class AgentCommunication:
    def __init__(self, registry):
        self.registry = registry
        self.message_queues: Dict[str, asyncio.Queue] = {}  # one per agent

    def ensure_agent_queue(self, agent_name: str):
        if agent_name not in self.message_queues:
            self.message_queues[agent_name] = asyncio.Queue()

    async def send_message(self, from_agent: str, to_agent: str, message: Dict[str, Any]):
        """Send a message from one agent to another."""
        self.ensure_agent_queue(to_agent)
        msg = {
            "from": from_agent,
            "to": to_agent,
            "payload": message,
            "type": message.get("type", "direct"),
        }
        await self.message_queues[to_agent].put(msg)

    async def broadcast(self, from_agent: str, varna: Optional[str], message: Dict[str, Any]):
        """Broadcast to all agents, or all of a given varna."""
        if varna:
            targets = [a for a in self.registry.get_all().values() if getattr(a, "varna", None) == varna]
        else:
            targets = self.registry.get_all().values()
        for agent in targets:
            await self.send_message(from_agent, getattr(agent, "name", ""), message)

    async def receive_message(self, agent_name: str, callback: Optional[Callable] = None):
        """Agent polls its queue for messages, optionally handles with a callback."""
        self.ensure_agent_queue(agent_name)
        msg = await self.message_queues[agent_name].get()
        if callback:
            await callback(msg)
        return msg

# DEMO
if __name__ == "__main__":
    import asyncio
    from core.agent_registry import AgentRegistry
    from core.dummy_agent import DummyAgent
    from agent.Vidya.vidya import Vidya

    async def vidya_callback(msg):
        print(f"Vidya received message: {msg}")

    async def main():
        registry = AgentRegistry()
        registry.register_agent(DummyAgent())
        registry.register_agent(Vidya(semantic_memory=None))
        comms = AgentCommunication(registry)

        # Dummy sends message to Vidya
        await comms.send_message("dummy", "vidya", {"type": "greet", "msg": "Om Vidya, what is dharmic synthesis?"})

        # Vidya listens & replies
        msg = await comms.receive_message("vidya", callback=vidya_callback)
        # Optionally, Vidya responds (simulate)
        await comms.send_message("vidya", "dummy", {"type": "response", "answer": "Dharmic synthesis is unity of wisdom."})
        dummy_msg = await comms.receive_message("dummy")
        print(f"Dummy received: {dummy_msg}")

    asyncio.run(main())
