# core/performance_monitor.py

import psutil
import time
from typing import Dict, Any, List

class PerformanceMonitor:
    """Monitors system/agent health—CPU, memory, fairness, and dharmic compliance."""

    def __init__(self, agents: List[str]):
        self.agents = agents
        # Fake agent stats for demo; in reality, you would get real measurements
        self.agent_stats: Dict[str, Dict[str, Any]] = {a: {"alloc": 0, "violations": 0, "uptime": 0} for a in agents}

    def record_stat(self, agent: str, stat: Dict[str, Any]):
        if agent in self.agent_stats:
            self.agent_stats[agent].update(stat)

    def get_system_metrics(self) -> Dict[str, Any]:
        """Returns system level metrics using psutil."""
        return {
            "cpu_percent": psutil.cpu_percent(interval=0.1),
            "mem_percent": psutil.virtual_memory().percent,
            "uptime_sec": time.time() - psutil.boot_time()
        }

    def get_agent_metrics(self) -> Dict[str, Dict[str, Any]]:
        """Return current stats for all agents."""
        return self.agent_stats

    def surf_warnings(self) -> List[str]:
        """Check for any agent/system warnings: overuse, many violations, etc."""
        warnings = []
        sys = self.get_system_metrics()
        if sys["cpu_percent"] > 80:
            warnings.append("High CPU usage!")
        if sys["mem_percent"] > 85:
            warnings.append("High memory usage!")
        for agent, stats in self.agent_stats.items():
            if stats["violations"] > 5:
                warnings.append(f"{agent} has excessive dharmic violations!")
        return warnings

if __name__ == "__main__":
    monitor = PerformanceMonitor(["vidya", "kaushal"])
    monitor.record_stat("vidya", {"alloc": 1000, "violations": 0, "uptime": 10000})
    monitor.record_stat("kaushal", {"alloc": 0, "violations": 6, "uptime": 8500})
    print("--- System metrics ---")
    print(monitor.get_system_metrics())
    print("--- Agent metrics ---")
    print(monitor.get_agent_metrics())
    print("--- Warnings ---")
    print(monitor.surf_warnings())
