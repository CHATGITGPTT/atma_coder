# core/resource_allocator.py

from core.workflow_optimizer import WorkflowOptimizer
from governance.karma_tracker import KarmaTracker
from governance.dharma_enforcer import DharmaEnforcer
from typing import List, Dict, Any, Optional

class ResourceAllocator:
    """Allocates resources to agents using karma/dharma priorities."""

    def __init__(self, agents: List[str], optimizer: Optional[WorkflowOptimizer] = None):
        self.agents = agents
        self.optimizer = optimizer
        self.allocations: Dict[str, Dict[str, Any]] = {a: {} for a in agents}

    def allocate(self, resource: str, amount: int) -> str:
        """Allocate resource (cpu/mem/slots/tokens) to best agent."""
        best_agent = self.optimizer.choose_agent_for_task(self.agents)
        current = self.allocations.get(best_agent, {})
        current[resource] = current.get(resource, 0) + amount
        self.allocations[best_agent] = current
        print(f"[RESOURCE ALLOCATOR] Allocated {amount} '{resource}' to {best_agent}")
        return best_agent

    def get_agent_allocation(self, agent: str) -> Dict[str, Any]:
        """Return all resources currently allocated to a given agent."""
        return self.allocations.get(agent, {})

if __name__ == "__main__":
    # Demo: allocate tokens and slots based on karma/dharma
    kt = KarmaTracker()
    de = DharmaEnforcer("config/dharma_enforcement.yaml")
    wo = WorkflowOptimizer(kt, de)

    kt.log_action("vidya", "ethics_audit", 20)
    kt.log_action("kaushal", "code_error", -10)

    allocator = ResourceAllocator(["vidya", "kaushal"], optimizer=wo)
    allocator.allocate("tokens", 1000)
    allocator.allocate("slots", 2)
    print("--- Current allocations ---")
    print("Vidya:", allocator.get_agent_allocation("vidya"))
    print("Kaushal:", allocator.get_agent_allocation("kaushal"))
