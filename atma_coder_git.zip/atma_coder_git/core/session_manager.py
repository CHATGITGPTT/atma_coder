import datetime
import uuid
from typing import Any, Dict, Optional

# Assign Varna to this module
from config.varna import VarnaEnum
from core.event_bus import EventBus

VARNA = VarnaEnum.SHUDRA  # Managing session data, a form of foundational infrastructure


class Session:
    """Represents a single interaction session with atma_coder."""

    def __init__(self, session_id: str, user_id: str | None = None):
        self.session_id = session_id
        self.user_id = user_id
        self.start_time = datetime.datetime.now()
        self.last_active_time = self.start_time
        self.history: list[Dict[str, Any]] = []  # Stores interaction logs, prompts, responses
        self.context: Dict[str, Any] = {}  # Stores session-specific context variables
        self.status: str = "active"
        print(f"[{VARNA.name}] Session {self.session_id} started for user {self.user_id or 'unknown'}.")

    def add_interaction(self, role: str, content: Any, metadata: Optional[Dict[str, Any]] = None):
        """Adds an interaction (e.g., user input, agent response) to the session history."""
        interaction = {
            "timestamp": datetime.datetime.now().isoformat(),
            "role": role,
            "content": content,
            "metadata": metadata if metadata is not None else {},
        }
        self.history.append(interaction)
        self.last_active_time = datetime.datetime.now()
        # print(f"[{VARNA.name}] Session {self.session_id}: Added {role} interaction.")

    def update_context(self, key: str, value: Any):
        """Updates a key-value pair in the session's context."""
        self.context[key] = value
        self.last_active_time = datetime.datetime.now()
        # print(f"[{VARNA.name}] Session {self.session_id}: Updated context for '{key}'.")

    def end_session(self, reason: str = "completed"):
        """Marks the session as ended."""
        self.status = "ended"
        self.end_time = datetime.datetime.now()
        print(
            f"[{VARNA.name}] Session {self.session_id} ended ({reason}). Duration: {self.end_time - self.start_time}."
        )


class SessionManager:
    """
    Manages active and historical user sessions.
    Responsible for creating, retrieving, updating, and expiring sessions.
    """

    def __init__(self, event_bus: EventBus, inactivity_timeout_minutes: int = 30):
        self._active_sessions: Dict[str, Session] = {}
        self._inactivity_timeout = datetime.timedelta(minutes=inactivity_timeout_minutes)
        self.event_bus = event_bus
        print(f"[{VARNA.name}] SessionManager initialized. Inactivity timeout: {inactivity_timeout_minutes} min.")

    def create_session(self, user_id: str | None = None) -> Session:
        """Creates a new session and returns it."""
        session_id = str(uuid.uuid4())
        new_session = Session(session_id, user_id)
        self._active_sessions[session_id] = new_session
        asyncio.create_task(self.event_bus.publish("session_created", session_id, user_id))
        return new_session

    def get_session(self, session_id: str) -> Session | None:
        """Retrieves an active session by its ID."""
        session = self._active_sessions.get(session_id)
        if session and session.status == "active":
            session.last_active_time = datetime.datetime.now()  # Update last active time on access
            return session
        return None

    def end_session(self, session_id: str, reason: str = "manual"):
        """Ends a session by its ID."""
        session = self._active_sessions.pop(session_id, None)
        if session:
            session.end_session(reason)
            asyncio.create_task(self.event_bus.publish("session_ended", session_id, reason))
            # Potentially save session history to persistent memory here
        else:
            print(f"[{VARNA.name}] Warning: Attempted to end non-existent or already ended session {session_id}.")

    async def _monitor_sessions(self):
        """Asynchronously monitors sessions for inactivity and expires them."""
        while True:
            await asyncio.sleep(60)  # Check every minute
            current_time = datetime.datetime.now()
            sessions_to_expire = []
            for session_id, session in self._active_sessions.items():
                if session.status == "active" and (current_time - session.last_active_time) > self._inactivity_timeout:
                    sessions_to_expire.append(session_id)

            for session_id in sessions_to_expire:
                print(f"[{VARNA.name}] Expiring inactive session: {session_id}")
                self.end_session(session_id, reason="inactivity_timeout")

    def start_monitoring(self):
        """Starts the background task for session monitoring."""
        asyncio.create_task(self._monitor_sessions())
        print(f"[{VARNA.name}] Session monitoring started.")
