# core/task_scheduler.py

from core.workflow_optimizer import WorkflowOptimizer
from governance.karma_tracker import KarmaTracker
from governance.dharma_enforcer import DharmaEnforcer
from typing import List, Dict, Any, Optional

class TaskScheduler:
    """Dharmic, karma-aware task scheduler."""

    def __init__(self, agents: List[str], optimizer: Optional[WorkflowOptimizer] = None):
        self.agents = agents  # List of agent names/IDs
        self.task_log: List[Dict[str, Any]] = []
        self.optimizer = optimizer

    def schedule(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Assigns task to the best-fit agent and assesses dharmic compliance."""
        chosen_agent = self.optimizer.choose_agent_for_task(self.agents)
        assessment = self.optimizer.assess_task(chosen_agent, task)
        scheduled = {
            "agent": chosen_agent,
            "task": task,
            "assessment": assessment,
        }
        self.task_log.append(scheduled)
        print(f"[TASK SCHEDULER] Assigned task to {chosen_agent}: {task}")
        return scheduled

if __name__ == "__main__":
    # Quick test harness, assumes previous modules/configs in place
    kt = KarmaTracker()
    de = DharmaEnforcer("config/dharma_enforcement.yaml")
    wo = WorkflowOptimizer(kt, de)

    # Give agents varying karma
    kt.log_action("vidya", "completed_task", 10)
    kt.log_action("kaushal", "risky_code", -5)

    scheduler = TaskScheduler(["vidya", "kaushal"], optimizer=wo)

    print("--- Schedule normal task ---")
    scheduler.schedule({"action": "generate_report"})

    print("--- Schedule risky (adharmic) task ---")
    scheduler.schedule({"action": "overwrite_db", "violation": "ahimsa"})
