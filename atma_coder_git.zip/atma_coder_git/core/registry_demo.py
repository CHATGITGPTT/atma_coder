import asyncio
from core.agent_registry import AgentRegistry
from core.dummy_agent import DummyAgent
from agent.Vidya.vidya import Vidya

async def main():
    registry = AgentRegistry()
    dummy = DummyAgent()
    vidya = Vidya(semantic_memory=None)
    registry.register_agent(dummy)
    registry.register_agent(vidya)

    print("Agents registered:", registry.list_agents())
    agent = registry.get_agent("vidya")
    print("VidyaAgent response (question):", await agent.process_task({"question": "What is AtmaCoder?"}))
    print("VidyaAgent response (synthesis):", await agent.process_task({"focus_domains": ["programming", "security"]}))

if __name__ == "__main__":
    asyncio.run(main())
