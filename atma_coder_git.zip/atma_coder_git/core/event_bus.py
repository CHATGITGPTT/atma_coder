import asyncio
import logging
from typing import Any, Callable, Coroutine, Dict, List

# Assign Varna to this module
from config.varna import VarnaEnum

VARNA = VarnaEnum.SHUDRA  # Foundational infrastructure for communication

logger = logging.getLogger(__name__)


class EventBus:
    """
    A simple asynchronous event bus for inter-component communication in atma_coder.
    Decouples modules, enforcing modularity and Varna-based separation.
    """

    def __init__(self):
        self._listeners: Dict[str, List[Callable[..., Coroutine[Any, Any, None]]]] = {}
        self._event_queues: Dict[str, asyncio.Queue] = {}
        logger.info(f"[{VARNA.name}] EventBus initialized.")

    def subscribe(self, event_type: str, handler: Callable[..., Coroutine[Any, Any, None]]):
        """
        Subscribes a handler coroutine to a specific event type.
        """
        if not asyncio.iscoroutinefunction(handler):
            logger.warning(f"[{VARNA.name}] Handler for {event_type} is not a coroutine function. It should be async.")
        self._listeners.setdefault(event_type, []).append(handler)
        logger.debug(f"[{VARNA.name}] Subscribed handler {handler.__name__} to event: {event_type}")

    def unsubscribe(self, event_type: str, handler: Callable[..., Coroutine[Any, Any, None]]):
        """
        Unsubscribes a handler from an event type.
        """
        if event_type in self._listeners and handler in self._listeners[event_type]:
            self._listeners[event_type].remove(handler)
            logger.debug(f"[{VARNA.name}] Unsubscribed handler {handler.__name__} from event: {event_type}")

    async def publish(self, event_type: str, *args, **kwargs):
        """
        Publishes an event, notifying all subscribed handlers.
        Handlers are executed concurrently.
        """
        logger.debug(f"[{VARNA.name}] Publishing event: {event_type} with args: {args}, kwargs: {kwargs}")
        if event_type in self._listeners:
            tasks = [handler(event_type, *args, **kwargs) for handler in self._listeners[event_type]]
            try:
                await asyncio.gather(*tasks, return_exceptions=True)  # Gather to allow all to run, report exceptions
            except Exception as e:
                logger.error(f"[{VARNA.name}] Error in one or more event handlers for {event_type}: {e}")
        else:
            logger.debug(f"[{VARNA.name}] No listeners for event type: {event_type}")

    async def send_to_queue(self, queue_name: str, item: Any):
        """
        Sends an item to a specific named queue. For one-to-one or producer-consumer patterns.
        """
        if queue_name not in self._event_queues:
            self._event_queues[queue_name] = asyncio.Queue()
            logger.info(f"[{VARNA.name}] Created new queue: {queue_name}")
        await self._event_queues[queue_name].put(item)
        logger.debug(f"[{VARNA.name}] Sent item to queue '{queue_name}'")

    async def receive_from_queue(self, queue_name: str) -> Any:
        """
        Receives an item from a specific named queue. Blocks if queue is empty.
        """
        if queue_name not in self._event_queues:
            self._event_queues[queue_name] = asyncio.Queue()  # Create queue if it doesn't exist
            logger.info(f"[{VARNA.name}] Created new queue: {queue_name} (on receive attempt)")
        item = await self._event_queues[queue_name].get()
        logger.debug(f"[{VARNA.name}] Received item from queue '{queue_name}'")
        return item

    async def wait_for_event(self, event_type: str, timeout: float | None = None) -> Any | None:
        """
        Waits for a specific event to be published and returns the first argument.
        This is a simplified blocking mechanism for high-level orchestration,
        not ideal for internal high-volume event processing.
        """
        future = asyncio.Future()

        async def _single_shot_handler(published_event_type: str, *args, **kwargs):
            if published_event_type == event_type and not future.done():
                future.set_result(args[0] if args else None)
                self.unsubscribe(event_type, _single_shot_handler)  # Unsubscribe after first trigger

        self.subscribe(event_type, _single_shot_handler)
        try:
            result = await asyncio.wait_for(future, timeout=timeout)
            logger.debug(f"[{VARNA.name}] Event '{event_type}' received.")
            return result
        except asyncio.TimeoutError:
            self.unsubscribe(event_type, _single_shot_handler)  # Clean up if timed out
            logger.warning(f"[{VARNA.name}] Timed out waiting for event '{event_type}'.")
            return None
        except Exception as e:
            self.unsubscribe(event_type, _single_shot_handler)
            logger.error(f"[{VARNA.name}] Error waiting for event '{event_type}': {e}")
            raise
