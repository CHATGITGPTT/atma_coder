# Consciousness Bus: Multi-level consciousness management and context
# core/consciousness_bus.py
"""
ConsciousnessBus: Coordinates the collective consciousness state of all agents.
Supports consciousness elevation, context sharing, and system-level introspection.
Acts as the 'mind' of AtmaCoder's unified agent ecosystem.
"""

import asyncio
from typing import Dict, Any, Optional, List

class ConsciousnessBus:
    def __init__(self, registry):
        self.registry = registry
        # Shared, dynamic state for all agents
        self.state: Dict[str, Any] = {
            "active_agents": [],
            "overall_health": 1.0,
            "consciousness_level": 1.0,
            "dharmic_alignment": 1.0,
            "insights": [],
            "timestamp": None
        }
        self.subscribers: List = []

    async def assess_consciousness(self):
        """Poll all agents for health; update system state."""
        agents = self.registry.get_all().values()
        health_scores = []
        active_agents = []
        for agent in agents:
            get_status_fn = getattr(agent, 'get_health_status', None)
            if asyncio.iscoroutinefunction(get_status_fn):
                status = await get_status_fn()
            else:
                status = get_status_fn() if callable(get_status_fn) else {}
            health = status.get("health_score", 1.0)
            health_scores.append(health)
            if status.get("status", "") == "active":
                active_agents.append(getattr(agent, "name", None))

        avg_health = sum(health_scores) / max(1, len(health_scores))
        self.state.update({
            "active_agents": active_agents,
            "overall_health": avg_health,
            "timestamp": asyncio.get_event_loop().time()
        })

    async def elevate_consciousness(self, agent_name: str, level: float = 1.0):
        """Temporarily elevate an agent's consciousness (e.g. for a critical task)."""
        agent = self.registry.get_agent(agent_name)
        if hasattr(agent, "consciousness_level"):
            agent.consciousness_level = level
            return {"status": "elevated", "agent": agent_name, "level": level}
        else:
            return {"status": "no_support", "agent": agent_name}

    async def share_insight(self, agent_name: str, insight: str):
        self.state.setdefault("insights", []).append({
            "agent": agent_name,
            "insight": insight,
            "time": asyncio.get_event_loop().time()
        })
        for handler in self.subscribers:
            await handler(agent_name, insight)

    def subscribe(self, handler):
        """Register a callback for new insights or state updates."""
        self.subscribers.append(handler)

    def get_state(self):
        return self.state

# DEMO/CLI
if __name__ == "__main__":
    import asyncio
    from core.agent_registry import AgentRegistry
    from core.dummy_agent import DummyAgent
    from agent.Vidya.vidya import Vidya

    async def insight_callback(agent, insight):
        print(f"[CONSCIOUSNESS BUS] Insight shared by {agent}: {insight}")

    async def main():
        registry = AgentRegistry()
        registry.register_agent(DummyAgent())
        registry.register_agent(Vidya(semantic_memory=None))

        bus = ConsciousnessBus(registry)
        bus.subscribe(insight_callback)

        # Assess initial system state
        await bus.assess_consciousness()
        print("=== AtmaCoder Collective Consciousness State ===")
        print(bus.get_state())

        # Elevate consciousness of Vidya
        result = await bus.elevate_consciousness("vidya", level=2.0)
        print(f"Elevation result: {result}")

        # Agents share insight
        await bus.share_insight("vidya", "Cross-domain bridge created between security and programming theory.")
        await bus.share_insight("dummy", "Idle, awaiting further dharmic revelation.")

        # Print state again
        print("Updated state:", bus.get_state())

    asyncio.run(main())
