# core/dummy_agent.py

from core.base_agent import BaseAgent

class DummyAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="dummy", varna="TEST", memory_store=None)

    def process_task(self, task_data, context=None):
        return {"result": "Hello from DummyAgent!", "input": task_data}

    def get_health_status(self):
        return {"status": "active", "health_score": 1.0}
