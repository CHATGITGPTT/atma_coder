import logging
from typing import Optional

from config.runtime_config import get_model, set_model

logger = logging.getLogger(__name__)

# Define available models and their fallback hierarchy
AVAILABLE_MODELS = {
    "gpt-3.5-turbo": "openai",
    "gpt-4": "openai", 
    "gpt-4-turbo": "openai",
    "claude-3-sonnet": "anthropic",
    "claude-3-opus": "anthropic",
    "gemini-pro": "google",
    "gemini-pro-vision": "google",
    "perplexity": "perplexity"
}

# Fallback hierarchy - if primary model fails, try these in order
FALLBACK_HIERARCHY = [
    "gpt-3.5-turbo",  # Most reliable fallback
    "claude-3-sonnet",
    "gemini-pro",
    "perplexity"
]

def route_model(prompt: str) -> str:
    """
    Enhanced model router with reliable fallback logic.
    """
    current_model = get_model()
    
    # Check if current model is valid
    if current_model not in AVAILABLE_MODELS:
        logger.warning(f"Invalid model '{current_model}' detected, attempting fallback")
        return _execute_fallback_chain(prompt)
    
    # Try current model first
    try:
        response = _call_model(current_model, prompt)
        if response and not _is_error_response(response):
            return response
        else:
            logger.warning(f"Model '{current_model}' returned error, attempting fallback")
            return _execute_fallback_chain(prompt)
    except Exception as e:
        logger.error(f"Model '{current_model}' failed: {e}")
        return _execute_fallback_chain(prompt)

def _execute_fallback_chain(prompt: str) -> str:
    """
    Execute fallback chain until a working model is found.
    """
    current_model = get_model()
    
    # Start with current model if it's in fallback hierarchy
    fallback_models = [current_model] if current_model in FALLBACK_HIERARCHY else []
    fallback_models.extend([m for m in FALLBACK_HIERARCHY if m != current_model])
    
    for model in fallback_models:
        try:
            logger.info(f"Attempting fallback to model: {model}")
            response = _call_model(model, prompt)
            
            if response and not _is_error_response(response):
                # Update current model to working fallback
                set_model(model)
                logger.info(f"Successfully switched to fallback model: {model}")
                return response
                
        except Exception as e:
            logger.warning(f"Fallback model '{model}' failed: {e}")
            continue
    
    # If all fallbacks fail, return a graceful error message
    logger.error("All models failed, returning fallback response")
    return _generate_fallback_response(prompt)

def _call_model(model: str, prompt: str) -> Optional[str]:
    """
    Call specific model with proper error handling.
    """
    try:
        if model.startswith("gpt"):
            return call_openai_api(model, prompt)
        elif model.startswith("claude"):
            return call_anthropic_api(model, prompt)
        elif model.startswith("gemini"):
            return call_gemini_api(model, prompt)
        elif model == "perplexity":
            return call_perplexity_api(model, prompt)
        else:
            logger.warning(f"Unknown model type: {model}")
            return None
    except Exception as e:
        logger.error(f"Error calling model {model}: {e}")
        return None

def _is_error_response(response: str) -> bool:
    """
    Check if response indicates an error.
    """
    error_indicators = [
        "error", "failed", "unknown model", "❌", "exception",
        "not available", "not found", "invalid", "unauthorized"
    ]
    
    response_lower = response.lower()
    return any(indicator in response_lower for indicator in error_indicators)

def _generate_fallback_response(prompt: str) -> str:
    """
    Generate a fallback response when all models fail.
    """
    return f"[System Fallback] I understand you're asking about: {prompt[:100]}... However, I'm currently experiencing technical difficulties with my external model connections. Please try again in a moment, or contact support if the issue persists."

def call_openai_api(model: str, prompt: str) -> str:
    """
    Enhanced OpenAI API call with proper error handling.
    """
    try:
        import openai
        import os
        
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise Exception("OpenAI API key not configured")
        
        client = openai.OpenAI(api_key=api_key)
        
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=1000,
            temperature=0.7
        )
        
        return response.choices[0].message.content.strip()
        
    except Exception as e:
        logger.error(f"OpenAI API call failed for {model}: {e}")
        raise

def call_anthropic_api(model: str, prompt: str) -> str:
    """
    Enhanced Anthropic API call with proper error handling.
    """
    try:
        import anthropic
        import os
        
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise Exception("Anthropic API key not configured")
        
        client = anthropic.Anthropic(api_key=api_key)
        
        response = client.messages.create(
            model=model,
            max_tokens=1000,
            messages=[{"role": "user", "content": prompt}]
        )
        
        return response.content[0].text.strip()
        
    except Exception as e:
        logger.error(f"Anthropic API call failed for {model}: {e}")
        raise

def call_gemini_api(model: str, prompt: str) -> str:
    """
    Enhanced Google Gemini API call with proper error handling.
    """
    try:
        import google.generativeai as genai
        import os
        
        api_key = os.getenv("GOOGLE_API_KEY")
        if not api_key:
            raise Exception("Google API key not configured")
        
        genai.configure(api_key=api_key)
        model_instance = genai.GenerativeModel(model)
        
        response = model_instance.generate_content(prompt)
        return response.text.strip()
        
    except Exception as e:
        logger.error(f"Gemini API call failed for {model}: {e}")
        raise

def call_perplexity_api(model: str, prompt: str) -> str:
    """
    Enhanced Perplexity API call with proper error handling.
    """
    try:
        import requests
        import os
        
        api_key = os.getenv("PERPLEXITY_API_KEY")
        if not api_key:
            raise Exception("Perplexity API key not configured")
        
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "llama-3.1-sonar-small-128k-online",
            "messages": [{"role": "user", "content": prompt}]
        }
        
        response = requests.post(
            "https://api.perplexity.ai/chat/completions",
            headers=headers,
            json=data,
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            return result["choices"][0]["message"]["content"].strip()
        else:
            raise Exception(f"Perplexity API returned status {response.status_code}")
            
    except Exception as e:
        logger.error(f"Perplexity API call failed for {model}: {e}")
        raise

def get_available_models() -> list:
    """
    Get list of available models.
    """
    return list(AVAILABLE_MODELS.keys())

def get_model_provider(model: str) -> Optional[str]:
    """
    Get the provider for a given model.
    """
    return AVAILABLE_MODELS.get(model)

def is_model_available(model: str) -> bool:
    """
    Check if a model is available.
    """
    return model in AVAILABLE_MODELS
