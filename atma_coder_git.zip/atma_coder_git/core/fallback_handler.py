import logging
from typing import Any, Dict

# Assign Varna to this module
from config.varna import VarnaEnum
from core.personality_core import PersonalityCore

VARNA = VarnaEnum.KSHATRIYA  # Safeguarding against failures, enforcing resilience

logger = logging.getLogger(__name__)


class FallbackHandler:
    """
    Handles unexpected errors, failures, ethical breaches, or unclear situations.
    Ensures the system degrades gracefully, communicates transparently (Satya),
    and maintains its ethical posture (Ahimsa, Svadharma).
    """

    def __init__(self):
        self.personality_core = PersonalityCore()
        logger.info(f"[{VARNA.name}] FallbackHandler initialized.")

    async def handle_failure(
        self, failure_context: str, exception: Exception | None = None, details: Dict[str, Any] | None = None
    ):
        """
        Manages a general system failure or operational error.
        Logs the error, informs the user, and attempts recovery if possible.
        """
        error_message = f"An operation encountered an unexpected issue: {failure_context}"
        log_details = f"Details: {details}" if details else ""
        if exception:
            log_details += f"\nException: {type(exception).__name__}: {exception}"

        logger.error(f"[{VARNA.name}] Failure detected. {error_message} {log_details}")

        # Respond to user via personality core
        user_response = (
            f"I have encountered an impediment in performing the requested action. "
            f"While I strive for perfection according to Tapasya, limitations occurred. "
            f"Reason: {failure_context}. I regret this deviation."
        )
        print(self.personality_core.wrap_response(user_response))

        # TODO: Implement recovery, retry mechanisms, or alert relevant modules
        await self._log_to_reflection_engine("operation_failure", error_message)

    async def handle_ethical_breach(self, breach_details: str):
        """
        Activates when an ethical guideline (Ahimsa, Svadharma) might have been violated
        or is prone to be violated. This is a critical state.
        """
        logger.critical(f"[{VARNA.name}] Potential Ethical Breach Detected: {breach_details}")

        user_response = (
            f"A potential breach of Dharma's principles (especially Ahimsa or Svadharma) "
            f"has been detected in my operation or a proposed action. "
            f"I am halting this path to ensure integrity. "
            f"Details: {breach_details}"
        )
        print(self.personality_core.wrap_response(user_response))

        # Log to reflection engine for introspection
        await self._log_to_reflection_engine("ethical_breach", breach_details)

        # Trigger audit or self-correction mechanism
        await self._trigger_audit(breach_details)

    async def handle_unknown_state(self, context: str):
        """
        Manages situations where the system enters an unexpected or undefined state.
        Emphasizes Satya by admitting uncertainty.
        """
        logger.warning(f"[{VARNA.name}] Unknown state encountered: {context}")

        user_response = self.personality_core.express_uncertainty(
            f"current state or required action based on '{context}'"
        )
        print(self.personality_core.wrap_response(user_response))

        # Attempt to gather more information or revert to a known safe state
        await self._log_to_reflection_engine("unknown_state", context)

    async def _log_to_reflection_engine(self, level: str, message: str):
        """
        Placeholder for logging critical events to the introspection engine or Bhavana.
        """
        # In a real system, this would publish an event to the EventBus
        # which an `introspection_engine` listener would pick up and log to `/memory/bhavana/`
        # for now, a direct print for simulation purposes.
        logger.info(f"[{VARNA.name}] Logging '{level}' event to reflection engine: {message[:100]}...")
        # Example: await self.event_bus.publish("reflection_log", level, message)

    async def _trigger_audit(self, context: str):
        """
        Triggers an internal audit (e.g., via the audit_agent) after a critical event.
        """
        # In a real system, this would publish an event to the EventBus
        # which an `audit_agent` listener would pick up.
        logger.info(f"[{VARNA.name}] Triggering internal audit due to: {context}")
        # Example: await self.event_bus.publish("trigger_audit", {"context": context})
