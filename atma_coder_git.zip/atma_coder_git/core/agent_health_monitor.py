# Agent Health Monitor: Tracks agent status and availability
# core/agent_health_monitor.py
"""
AgentHealthMonitor: Polls the agent registry to gather agent health/status.
Returns a full system health overview for dashboards, logs, or CLI.
"""

import asyncio

class AgentHealthMonitor:
    def __init__(self, registry):
        self.registry = registry

    async def get_all_agent_health(self):
        """Query all registered agents for their health status (async)."""
        agents = self.registry.get_all().values()
        health_reports = {}

        for agent in agents:
            # Check if agent has an async 'get_health_status'
            get_status_fn = getattr(agent, 'get_health_status', None)
            if asyncio.iscoroutinefunction(get_status_fn):
                health = await get_status_fn()
            elif callable(get_status_fn):
                health = get_status_fn()
            else:
                health = {"status": "unknown", "agent": getattr(agent, "name", None)}
            health_reports[getattr(agent, "name", None)] = health

        return health_reports

if __name__ == "__main__":
    # Demo/test CLI:
    from core.agent_registry import AgentRegistry
    from core.dummy_agent import DummyAgent
    from agent.Vidya.vidya import Vidya

    async def main():
        registry = AgentRegistry()
        registry.register_agent(DummyAgent())
        registry.register_agent(Vidya(semantic_memory=None))
        monitor = AgentHealthMonitor(registry)
        all_health = await monitor.get_all_agent_health()
        print("=== AtmaCoder Agent Health ===")
        for agent, status in all_health.items():
            print(f"[{agent}] {status}")

    asyncio.run(main())
