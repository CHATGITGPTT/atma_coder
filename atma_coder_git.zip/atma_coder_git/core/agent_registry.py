# Agent Registry: Registers and manages all agents in AtmaCoder
# core/agent_registry.py

from typing import Dict, Any
from core.base_agent import BaseAgent

class AgentRegistry:
    def __init__(self):
        self.agents: Dict[str, BaseAgent] = {}

    def register_agent(self, agent: BaseAgent):
        self.agents[agent.name] = agent

    def get_agent(self, name: str) -> BaseAgent:
        return self.agents.get(name)

    def list_agents(self):
        return list(self.agents.keys())

    def get_all(self):
        return self.agents
