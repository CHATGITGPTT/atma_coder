# core/workflow_optimizer.py
from governance.karma_tracker import KarmaTracker
from governance.dharma_enforcer import DharmaEnforcer
from typing import Dict, Any, List, Optional

class WorkflowOptimizer:
    """Optimizes agent workflows with karma and dharma criteria."""

    def __init__(self, karma_tracker: Optional[KarmaTracker] = None, dharma_enforcer: Optional[DharmaEnforcer] = None):
        self.karma_tracker = karma_tracker
        self.dharma_enforcer = dharma_enforcer

    def choose_agent_for_task(self, candidate_agents: List[str]) -> str:
        """Selects the most dharmically fit agent for a task, based on karma score."""
        # Higher karma = preferred
        scored = [(agent, self.karma_tracker.score_agent(agent)) for agent in candidate_agents]
        scored.sort(key=lambda x: x[1], reverse=True)
        chosen = scored[0][0] if scored else None
        print(f"[WORKFLOW OPTIMIZER] Choosing agent: {chosen} (scores: {scored})")
        return chosen

    def assess_task(self, agent: str, task: Dict[str, Any]) -> Dict[str, Any]:
        """Assess a proposed task for dharmic compliance; invokes enforcer if needed."""
        if "violation" in task:  # Dummy signal for demo
            result = self.dharma_enforcer.handle_violation(agent, task["violation"], task)
        else:
            result = {"status": "clear"}
        print(f"[WORKFLOW OPTIMIZER] Task assessment: {result}")
        return result

if __name__ == "__main__":
    # Simple integration test (assumes you previously ran your YAML/config steps)
    kt = KarmaTracker()
    de = DharmaEnforcer("config/dharma_enforcement.yaml")
    # Give a karma advantage to vidya
    kt.log_action("vidya", "completed_task", 15)
    kt.log_action("kaushal", "risky_code", -10)
    wf = WorkflowOptimizer(kt, de)
    wf.choose_agent_for_task(["vidya", "kaushal"])
    wf.assess_task("kaushal", {"action": "do_something", "violation": "ahimsa"})
