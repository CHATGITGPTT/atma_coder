# Assign Varna to this module
from config.varna import VarnaEnum

VARNA = VarnaEnum.BRAHMAN  # Central nervous system initializer
