# BaseAgent: Abstract base class for dharmic agents
# core/base_agent.py

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

class BaseAgent(ABC):
    def __init__(self, name: str, varna: str, memory_store: Optional[Any] = None):
        self.name = name
        self.varna = varna
        self.memory = memory_store
        self.status = "active"
        self.health_score = 1.0
        self.error_count = 0

    @abstractmethod
    def process_task(self, task_data: Dict[str, Any], context: Dict[str, Any] = None) -> Any:
        """Process a task and return a structured response."""
        pass

    @abstractmethod
    def get_health_status(self) -> Dict[str, Any]:
        """Return agent's current health status."""
        pass

    def get_capabilities(self):
        """Return agent's capabilities as a list of strings."""
        return []

    def get_dependencies(self):
        """Return dependencies as a list of strings."""
        return []
