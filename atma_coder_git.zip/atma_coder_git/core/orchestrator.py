import asyncio
import logging
from typing import Any, Dict, List

from automation.workflow_engine import WorkflowEngine  # VAISHYA
from config.api_router import APIRouter  # VAISHYA

# Import modules based on Varna
from config.keychain_manager import KeychainManager  # KSHATRIYA
from config.settings import AppSettings
from config.varna import VarnaEnum
from core.event_bus import EventBus
from core.fallback_handler import FallbackHandler
from core.heartbeat_monitor import HeartbeatMonitor
from core.personality_core import PersonalityCore
from core.session_manager import SessionManager
from governance.ethical_engine import EthicalEngine  # KSHATRIYA
from governance.karma_tracker import KarmaTracker
from governance.dharma_enforcer import DharmaEnforcer
from core.workflow_optimizer import WorkflowOptimizer
from core.task_scheduler import TaskScheduler
from core.resource_allocator import ResourceAllocator
from core.performance_monitor import PerformanceMonitor
from governance.refusal_logic import RefusalLogic  # KSHATRIYA
from intelligence.critic import Critic  # BRAHMAN
from intelligence.planner import Planner  # BRAHMAN
from intelligence.reasoner import Reasoner  # BRAHMAN
from memory.episodic_memory import EpisodicMemory
from memory.graph_store import SQLiteGraphClient  # 🔥 persistent memory
from memory.memory_logger import MemoryLogger  # NEW
from memory.semantic_memory import SemanticMemory  # BRAHMAN/VAISHYA
from security.advanced_security_analytics import integrate_advanced_analytics
from tools.sandbox import Sandbox  # SHUDRA

VARNA = VarnaEnum.BRAHMAN

# Enable comprehensive logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


class Orchestrator:
    def __init__(self, settings: AppSettings, event_bus: EventBus):
        self.settings = settings
        self.event_bus = event_bus
        self.personality_core = PersonalityCore()
        self.session_manager = SessionManager(event_bus)
        self.fallback_handler = FallbackHandler()
        self.heartbeat_monitor = HeartbeatMonitor(event_bus)

        # 🧠 Initialize persistent memory FIRST
        logger.info("Initializing persistent memory system...")
        self.graph_store = SQLiteGraphClient("memory_graph.sqlite")
        self.memory = MemoryLogger(self.graph_store)
        logger.info("Memory integration initialized successfully")

        self.keychain_manager = KeychainManager(settings)
        self.api_router = APIRouter()
        self.ethical_engine = EthicalEngine(settings, event_bus, self.personality_core)
        self.refusal_logic = RefusalLogic(self.ethical_engine)
        self.semantic_memory = SemanticMemory(settings.db_config, event_bus)
        self.planner = Planner(self.api_router, self.semantic_memory)
        self.reasoner = Reasoner(self.api_router, self.semantic_memory)
        self.critic = Critic(self.ethical_engine, self.event_bus)
        self.episodic_memory = EpisodicMemory(settings.data_dir, event_bus)
        self.sandbox = Sandbox(settings, event_bus, self.ethical_engine, self.episodic_memory)
        self.workflow_engine = WorkflowEngine(self.event_bus, self.ethical_engine)

        self.initialized = False
        logger.info(f"[{VARNA.name}] Orchestrator initialized. Core components ready.")

        # === AtmaCoder dharmic orchestration modules ===
        agent_names = [
            "Anusandhan",
            "AtmaPariksha",
            "KarmaTracker",
            "Kaushal",
            "MokshaPath",
            "Prajna",
            "Rakshak",
            "Sanrakshak",
            "Santulan",
            "Smriti",
            "Vidya",
            "Vivek",
        ]
        self.karma = KarmaTracker()
        self.dharma = DharmaEnforcer("config/dharma_enforcement.yaml")
        self.optimizer = WorkflowOptimizer(self.karma, self.dharma)
        self.scheduler = TaskScheduler(agent_names, self.optimizer)
        self.allocator = ResourceAllocator(agent_names, self.optimizer)
        self.monitor = PerformanceMonitor(agent_names)
        # ===============================================

    async def start(self):
        if self.initialized:
            logger.info(f"[{VARNA.name}] Orchestrator already running.")
            return

        logger.info(f"[{VARNA.name}] Starting atma_coder deep initialization...")
        await self.ethical_engine.load_ethical_guidelines("config/ethics_policy.yaml")
        await self.heartbeat_monitor.start()
        await self.semantic_memory.initialize()

        self.initialized = True
        logger.info(f"[{VARNA.name}] atma_coder system fully operational.")
        await self._main_loop()

    async def _main_loop(self):
        logger.info(f"[{VARNA.name}] Entering main orchestration loop. Awaiting tasks...")
        while True:
            task = await self.event_bus.wait_for_event("new_user_intent")
            if task:
                logger.debug(f"[{VARNA.name}] Received new task: {task.get('description', 'No description')}")
                await self.process_task(task)
            await asyncio.sleep(0.1)

    async def process_task(self, task_data: Dict[str, Any]):
        task_id = task_data.get("id", "N/A")
        description = task_data.get("description", "A general task")
        logger.info(f"[{VARNA.name}] Processing task [{task_id}]: {description}")

        # 🧠 STEP 1: Log task to persistent memory
        logger.info("🧠 Logging task to persistent memory...")
        try:
            task_uid = self.memory.log_task(description)
            logger.info(f"✅ Task logged with persistent ID: {task_uid}")
        except Exception as e:
            logger.error(f"❌ Failed to log task to memory: {e}")
            # Continue processing even if memory logging fails
            task_uid = f"fallback-{task_id}"

        # 🤖 STEP 1A: Advanced Security Analytics - Initial Assessment
        initial_nodes = 0
        initial_edges = 0
        try:
            logger.info("🤖 Running initial security analytics...")
            analytics_result = await integrate_advanced_analytics(
                {
                    "nodes_added": initial_nodes,
                    "edges_added": initial_edges,
                    "task_id": task_uid,
                    "task_type": self._classify_task_type(description),
                    "complexity_score": self._calculate_task_complexity(description),
                }
            )

            if analytics_result.get("alerts"):
                logger.warning(f"🚨 Pre-execution security alerts: {len(analytics_result['alerts'])}")
                for alert in analytics_result.get("alerts", [])[:3]:  # Show first 3
                    logger.warning(f"   ⚠️ {alert.get('type', 'UNKNOWN')}: {alert.get('message', 'No details')}")

            # Check for critical threats that should block execution
            integrated_assessment = analytics_result.get("integrated_assessment", {})
            if integrated_assessment.get("security_status") == "CRITICAL_THREAT":
                logger.error("🚨 CRITICAL SECURITY THREAT - Aborting task execution")
                try:
                    self.memory.log_error(task_uid, "Task blocked due to critical security threat", "SecurityAnalytics")
                except Exception as mem_e:
                    logger.error(f"Failed to log security block: {mem_e}")
                return

        except Exception as e:
            logger.error(f"❌ Advanced analytics failed: {e}")
            # Continue processing - don't let analytics failures block normal operation

        # Ethical check
        refusal_reason = await self.refusal_logic.check_request(task_data)
        if refusal_reason:
            logger.warning(f"[{VARNA.name}] Task [{task_id}] refused: {refusal_reason}")
            self.personality_core.respond_with_refusal(refusal_reason)
            # Log refusal to memory
            try:
                self.memory.log_error(task_uid, f"Ethical refusal: {refusal_reason}", "RefusalLogic")
            except Exception as e:
                logger.error(f"Failed to log refusal: {e}")
            return

        # 🧠 STEP 2: Planning phase
        plan_steps = []
        planning_nodes = 0
        planning_edges = 0

        try:
            logger.info(f"[{VARNA.name}] Generating plan for task [{task_id}]...")
            plan = await self.planner.create_plan(description)

            # Extract plan steps in the format memory logger expects
            if hasattr(plan, "get_steps_summary"):
                plan_steps = plan.get_steps_summary()
            elif hasattr(plan, "steps"):
                plan_steps = [str(step) for step in plan.steps]
            elif isinstance(plan, list):
                plan_steps = [str(step) for step in plan]
            else:
                plan_steps = [str(plan)]

            # Estimate planning consciousness growth
            planning_nodes = len(plan_steps) * 2  # Rough estimate
            planning_edges = len(plan_steps) * 3

            logger.info(f"[{VARNA.name}] Generated plan for task [{task_id}]: {plan_steps}")

            # Log plan to memory
            logger.info("🧠 Logging plan to persistent memory...")
            self.memory.log_plan(task_uid, plan_steps)
            logger.info(f"✅ Plan logged for task {task_uid}")

        except Exception as e:
            logger.error(f"[{VARNA.name}] Failed to generate plan for task [{task_id}]: {e}")

            # Log planning error
            try:
                self.memory.log_error(task_uid, f"Planning failed: {str(e)}", "Planner")
            except Exception as mem_e:
                logger.error(f"Failed to log planning error: {mem_e}")

            await self.fallback_handler.handle_failure(f"Planning failed for '{description}'.", exception=e)
            return

        # 🧠 STEP 3: Execution phase
        execution_successful = False
        execution_result = {}
        execution_nodes = 0
        execution_edges = 0

        try:
            logger.info(f"[{VARNA.name}] Executing workflow for task [{task_id}]...")
            workflow_result = await self.workflow_engine.execute_plan(plan)
            execution_successful = True

            # Estimate execution consciousness growth
            execution_nodes = len(plan_steps) * 4  # More growth during execution
            execution_edges = len(plan_steps) * 5

            # Prepare execution result for memory
            execution_result = {
                "status": "success",
                "workflow_result": str(workflow_result) if workflow_result else "completed",
                "plan_steps_count": len(plan_steps),
                "executed_at": task_id,
            }

            logger.info(f"[{VARNA.name}] Task [{task_id}] workflow executed successfully.")

            # Log execution to memory
            logger.info("🧠 Logging execution to persistent memory...")
            exec_id = self.memory.log_execution(task_uid, execution_result)
            logger.info(f"✅ Execution logged with ID: {exec_id}")

        except Exception as e:
            logger.error(f"[{VARNA.name}] Workflow execution failed for task [{task_id}]: {e}")

            # Log execution failure
            execution_result = {"status": "failed", "error": str(e), "plan_steps_count": len(plan_steps)}

            try:
                self.memory.log_execution(task_uid, execution_result)
                self.memory.log_error(task_uid, f"Execution failed: {str(e)}", "WorkflowEngine")
            except Exception as mem_e:
                logger.error(f"Failed to log execution failure: {mem_e}")

            await self.fallback_handler.handle_failure(f"Execution failed for '{description}'.", exception=e)

        # 🧠 STEP 4: Evaluation phase
        evaluation_nodes = 0
        evaluation_edges = 0
        critic_score = 0.0  # 🔧 CRITICAL FIX: Initialize here to ensure it's always defined

        if execution_successful:
            try:
                logger.info(f"[{VARNA.name}] Evaluating outcome for task [{task_id}]...")
                evaluation_result = await self.critic.evaluate_outcome(
                    original_goal=description,
                    executed_plan_summary=plan_steps,
                    outcome_data=execution_result.get("workflow_result", "Success metrics from workflow"),
                )

                # Estimate evaluation consciousness growth
                evaluation_nodes = 3  # Small growth during evaluation
                evaluation_edges = 4

                logger.info(f"[{VARNA.name}] Task [{task_id}] evaluation: {evaluation_result}")

                # Extract score and notes for memory
                critic_score = 1.0  # Default success score
                critic_notes = "Task completed successfully"

                if isinstance(evaluation_result, dict):
                    critic_score = evaluation_result.get("score", 1.0)
                    critic_notes = evaluation_result.get("notes", str(evaluation_result))
                else:
                    critic_notes = str(evaluation_result)

                # Log evaluation to memory
                logger.info("🧠 Logging evaluation to persistent memory...")
                self.memory.log_evaluation(task_uid, critic_score, critic_notes)
                logger.info(f"✅ Evaluation logged for task {task_uid}")

                # Handle ethical breaches
                if isinstance(evaluation_result, dict) and "ethical_breach" in evaluation_result:
                    await self.ethical_engine.log_ethical_violation(evaluation_result["ethical_breach"])
                    await self.fallback_handler.handle_ethical_breach(
                        evaluation_result.get("ethical_breach_details", "Unknown breach")
                    )
                    try:
                        self.memory.log_error(
                            task_uid, f"Ethical breach: {evaluation_result['ethical_breach']}", "Critic"
                        )
                    except Exception as mem_e:
                        logger.error(f"Failed to log ethical breach: {mem_e}")
                else:
                    self.personality_core.respond_with_success(
                        f"Task '{description}' completed successfully and ethically sound."
                    )

            except Exception as e:
                logger.error(f"[{VARNA.name}] Failed to evaluate task [{task_id}]: {e}")
                critic_score = 0.0  # 🔧 CRITICAL FIX: Set score on exception
                try:
                    self.memory.log_evaluation(task_uid, critic_score, f"Evaluation failed: {str(e)}")
                except Exception as mem_e:
                    logger.error(f"Failed to log evaluation failure: {mem_e}")
        else:
            # Log failed task evaluation
            critic_score = 0.0  # 🔧 CRITICAL FIX: Set score for failed execution
            try:
                self.memory.log_evaluation(task_uid, critic_score, "Task execution failed")
            except Exception as mem_e:
                logger.error(f"Failed to log failed task evaluation: {mem_e}")

            self.personality_core.respond_with_failure(f"Task '{description}' could not be completed.")

        # 🤖 STEP 5: Final Advanced Security Analytics
        total_nodes = planning_nodes + execution_nodes + evaluation_nodes
        total_edges = planning_edges + execution_edges + evaluation_edges

        try:
            logger.info("🤖 Running final security analytics...")

            # 🔧 FIX: Ensure critic_score is always defined
            safe_critic_score = 0.0
            if execution_successful:
                # Check if critic_score was successfully set during evaluation
                safe_critic_score = locals().get("critic_score", 0.0)

            final_analytics = await integrate_advanced_analytics(
                {
                    "nodes_added": total_nodes,
                    "edges_added": total_edges,
                    "task_id": task_uid,
                    "task_type": self._classify_task_type(description),
                    "complexity_score": self._calculate_task_complexity(description),
                    "execution_success": execution_successful,
                    "critic_score": safe_critic_score,  # Use the safely defined variable
                }
            )

            # Log significant analytics findings
            final_assessment = final_analytics.get("integrated_assessment", {})
            security_status = final_assessment.get("security_status", "UNKNOWN")
            risk_score = final_assessment.get("integrated_risk_score", 0.0)

            logger.info(f"🤖 Final Security Status: {security_status} (Risk: {risk_score:.2f})")

            if final_analytics.get("alerts"):
                logger.info(f"🚨 Post-execution security alerts: {len(final_analytics['alerts'])}")

            # Log any high-risk findings
            if risk_score > 0.7:
                logger.warning(f"⚠️ HIGH RISK TASK DETECTED: {task_uid} - Risk Score: {risk_score:.2f}")
                try:
                    self.memory.log_error(task_uid, f"High-risk task detected: {risk_score:.2f}", "SecurityAnalytics")
                except Exception as mem_e:
                    logger.error(f"Failed to log high-risk finding: {mem_e}")

            # Log dharmic assessment
            dharmic_assessment = final_assessment.get("dharmic_assessment", {})
            dharmic_health = dharmic_assessment.get("overall_dharmic_health", 1.0)
            logger.info(f"🕉️ Dharmic Health: {dharmic_health:.2f}")

        except Exception as e:
            logger.error(f"❌ Final analytics failed: {e}")

        # 🧠 STEP 6: Verify memory persistence
        try:
            logger.info("🧠 Verifying task was persisted to memory...")
            task_summary = self.memory.get_task_summary(task_uid)
            if task_summary:
                logger.info(f"✅ Task {task_uid} successfully persisted with {len(task_summary)} components")
            else:
                logger.warning(f"⚠️ Task {task_uid} may not have been properly persisted")
        except Exception as e:
            logger.error(f"❌ Failed to verify memory persistence: {e}")

        logger.info(f"[{VARNA.name}] Task [{task_id}] processing completed.")

    def _classify_task_type(self, description: str) -> str:
        """Classify task type for analytics"""
        description_lower = description.lower()

        if any(keyword in description_lower for keyword in ["plan", "strategy", "design", "architecture"]):
            return "planning"
        elif any(keyword in description_lower for keyword in ["analyze", "reason", "think", "solve"]):
            return "reasoning"
        elif any(keyword in description_lower for keyword in ["create", "generate", "write", "code"]):
            return "creative"
        elif any(keyword in description_lower for keyword in ["chat", "talk", "discuss", "explain"]):
            return "chat"
        elif any(keyword in description_lower for keyword in ["evaluate", "assess", "review", "judge"]):
            return "evaluation"
        else:
            return "general"

    def _calculate_task_complexity(self, description: str) -> float:
        """Calculate estimated task complexity for analytics"""
        # Base complexity from description length
        base_complexity = min(len(description) / 100.0, 2.0)

        # Adjust for complexity indicators
        complexity_indicators = [
            "complex",
            "difficult",
            "advanced",
            "sophisticated",
            "intricate",
            "comprehensive",
            "detailed",
            "thorough",
            "multi-step",
            "analysis",
        ]

        simplicity_indicators = ["simple", "basic", "easy", "quick", "brief", "short"]

        description_lower = description.lower()

        # Add complexity
        for indicator in complexity_indicators:
            if indicator in description_lower:
                base_complexity += 0.5

        # Reduce for simplicity
        for indicator in simplicity_indicators:
            if indicator in description_lower:
                base_complexity -= 0.3

        return max(0.1, min(base_complexity, 5.0))  # Clamp between 0.1 and 5.0

    async def explain_identity(self) -> Dict[str, Any]:
        return {
            "name": "AtmaCoder",
            "role": "Self-evolving AI software engineer",
            "dharma": [
                "Pursue Truth (Satya)",
                "Cause no Harm (Ahimsa)",
                "Serve with Clarity and Precision",
                "Uphold ethical development practices",
            ],
            "varna": VARNA.name,
        }

    async def stop(self):
        if not self.initialized:
            logger.info(f"[{VARNA.name}] Orchestrator not running, nothing to stop.")
            return

        logger.info(f"[{VARNA.name}] Shutting down atma_coder system...")
        await self.heartbeat_monitor.stop()
        await self.semantic_memory.shutdown()
        logger.info(f"[{VARNA.name}] All components stopped.")
        self.initialized = False

    # 🧠 New memory inspection methods
    def get_recent_tasks(self, limit: int = 5) -> List[Dict[str, Any]]:
        """Get recent tasks from memory for debugging"""
        try:
            return self.memory.get_recent_tasks(limit)
        except Exception as e:
            logger.error(f"Failed to get recent tasks: {e}")
            return []

    def get_memory_stats(self) -> Dict[str, int]:
        """Get memory statistics for monitoring"""
        try:
            tasks = self.graph_store.get_all_nodes_by_label("Task")
            components = self.graph_store.get_all_nodes_by_label("Component")
            executions = self.graph_store.get_all_nodes_by_label("Execution")
            evaluations = self.graph_store.get_all_nodes_by_label("Evaluation")

            return {
                "total_tasks": len(tasks),
                "total_components": len(components),
                "total_executions": len(executions),
                "total_evaluations": len(evaluations),
            }
        except Exception as e:
            logger.error(f"Failed to get memory stats: {e}")
            return {"error": str(e)}

    # 🤖 New advanced analytics methods
    async def get_security_analytics_report(self) -> Dict[str, Any]:
        """Get comprehensive security analytics report"""
        try:
            from security.advanced_security_analytics import AdvancedSecurityAnalytics

            analytics = AdvancedSecurityAnalytics()
            return await analytics.get_comprehensive_security_report()
        except Exception as e:
            logger.error(f"Failed to get security analytics report: {e}")
            return {"error": str(e)}

    async def get_threat_prediction(self, minutes: int = 60) -> Dict[str, Any]:
        """Get threat prediction for next N minutes"""
        try:
            from security.threat_predictor import DharmicThreatPredictor

            predictor = DharmicThreatPredictor()
            return predictor.predict_threat_likelihood(minutes)
        except Exception as e:
            logger.error(f"Failed to get threat prediction: {e}")
            return {"error": str(e)}

    def awaken_agents(self):
        """Awaken all 12 agents with diagnostic tasks"""
        task_map = {
            "Anusandhan": {"action": "perform_research"},
            "AtmaPariksha": {"action": "evaluate_decision"},
            "KarmaTracker": {"action": "log_karma"},
            "Kaushal": {"action": "generate_tool"},
            "MokshaPath": {"action": "detect_blocker"},
            "Prajna": {"action": "pattern_discovery"},
            "Rakshak": {"action": "scan_threat"},
            "Sanrakshak": {"action": "audit_code"},
            "Santulan": {"action": "balance_load"},
            "Smriti": {"action": "consolidate_memory"},
            "Vidya": {"action": "synthesize_knowledge"},
            "Vivek": {"action": "validate_ethics"},
        }
        
        logger.info("🔱 Awakening all 12 dharmic agents...")
        for agent, task in task_map.items():
            try:
                self.scheduler.schedule({"action": task["action"], "agent": agent})
                logger.info(f"  ✅ {agent}: {task['action']}")
            except Exception as e:
                logger.error(f"  ❌ {agent}: Failed to schedule - {e}")
        
        logger.info("🔱 All agents awakened with diagnostic tasks")

if __name__ == "__main__":
    import sys

    # --- Correct import paths ---
    from config.settings import AppSettings
    from core.event_bus import EventBus

    # --- Initialize settings and event bus ---
    settings = AppSettings()  # Use the correct constructor
    event_bus = EventBus()

    # --- List all registered agents ---
    agents = [
        "Anusandhan",
        "AtmaPariksha",
        "KarmaTracker",
        "Kaushal",
        "MokshaPath",
        "Prajna",
        "Rakshak",
        "Sanrakshak",
        "Santulan",
        "Smriti",
        "Vidya",
        "Vivek",
    ]

    orch = Orchestrator(settings, event_bus)
    
    if "--awaken" in sys.argv:
        print("\n🔱 AWAKENING ALL DHARMIC AGENTS 🔱\n")
        orch.awaken_agents()
        print("\n✅ All 12 agents have been awakened with diagnostic tasks!")
        print("   Use --report to see system status and agent metrics.\n")
    elif "--report" in sys.argv:
        print("\n*** ATMACODER SYSTEM REPORT ***\n")
        try:
            print("Agents:", agents)
            print("\n-- Karma scores --")
            for agent in agents:
                print(f"  {agent}: {orch.karma.score_agent(agent)}")
            print("\n-- Recent dharma violations --")
            print(getattr(orch.dharma, "violations", "N/A"))
            print("\n-- System metrics --")
            print(orch.monitor.get_system_metrics())
            print("\n-- Agent metrics --")
            print(orch.monitor.get_agent_metrics())
            if hasattr(orch, 'graph_store'):
                print("\n-- Knowledge Graph --")
                print("  Nodes:", orch.graph_store.node_count())
                print("  Edges:", orch.graph_store.edge_count())
        except Exception as e:
            print("Error collecting report:", e)
        print("\n*** END OF REPORT ***\n")
    else:
        print("Orchestrator started. Available commands:")
        print("  --awaken  : Awaken all 12 agents with diagnostic tasks")
        print("  --report  : Show system status and metrics")
