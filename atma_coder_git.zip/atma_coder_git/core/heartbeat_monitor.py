import asyncio
import datetime
import logging

# Assign Varna to this module
from config.varna import VarnaEnum
from core.event_bus import EventBus

VARNA = VarnaEnum.SHUDRA  # Infrastructure maintenance, ensuring system liveness

logger = logging.getLogger(__name__)


class HeartbeatMonitor:
    """
    Monitors the liveness and basic health of the atma_coder system.
    Periodically emits a 'heartbeat' event and can check critical component statuses.
    Ensures system stability—a core aspect of Ahimsa (non-harm by maintaining stable operation).
    """

    def __init__(self, event_bus: EventBus, interval_seconds: int = 15):
        self.event_bus = event_bus
        self.interval_seconds = interval_seconds
        self._running = False
        self._heartbeat_task = None
        self.last_heartbeat = None
        logger.info(f"[{VARNA.name}] HeartbeatMonitor initialized with interval: {interval_seconds}s.")

    async def _heartbeat_loop(self):
        """Continously publishes heartbeat events."""
        while self._running:
            try:
                timestamp = datetime.datetime.now().isoformat()
                status = self._check_basic_health()
                self.last_heartbeat = timestamp
                logger.debug(f"[{VARNA.name}] Emitting heartbeat. Status: {status['overall_status']}")
                await self.event_bus.publish("system_heartbeat", {"timestamp": timestamp, "status": status})
            except Exception as e:
                logger.error(f"[{VARNA.name}] Error during heartbeat emission: {e}")
            await asyncio.sleep(self.interval_seconds)

    def _check_basic_health(self) -> dict:
        """
        Performs basic checks on core system components.
        This is a placeholder and should be expanded to query actual component states.
        """
        health_status = {
            "overall_status": "healthy",
            "components": {
                "event_bus": "active",  # Event bus is always active if this is running
                "memory_system": "unknown",  # Placeholder
                "api_connectivity": "unknown",  # Placeholder
                "sandbox_status": "unknown",  # Placeholder
            },
            "uptime_seconds": (
                (datetime.datetime.now() - self.start_time).total_seconds() if hasattr(self, "start_time") else 0
            ),
        }

        # TODO: Implement actual checks. E.g.:
        # - Ping database from memory.semantic_memory
        # - Attempt a small, non-destructive call via config.api_router
        # - Check sandbox readiness from tools.sandbox

        for comp, status in health_status["components"].items():
            if status == "unhealthy" or status == "critical":
                health_status["overall_status"] = (
                    "degraded" if health_status["overall_status"] != "critical" else health_status["overall_status"]
                )
            if status == "critical":
                health_status["overall_status"] = "critical"
        return health_status

    async def start(self):
        """Starts the heartbeat monitoring loop."""
        if self._running:
            logger.info(f"[{VARNA.name}] HeartbeatMonitor is already running.")
            return

        self._running = True
        self.start_time = datetime.datetime.now()
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        logger.info(f"[{VARNA.name}] HeartbeatMonitor started.")

    async def stop(self):
        """Stops the heartbeat monitoring loop."""
        if self._running and self._heartbeat_task:
            self._running = False
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task  # Await to ensure it's cancelled cleanly
                logger.info(f"[{VARNA.name}] HeartbeatMonitor stopped.")
            except asyncio.CancelledError:
                logger.info(f"[{VARNA.name}] HeartbeatMonitor task cancelled successfully.")
            finally:
                self._heartbeat_task = None
        else:
            logger.info(f"[{VARNA.name}] HeartbeatMonitor not running.")

    def get_last_heartbeat_time(self) -> str | None:
        """Returns the timestamp of the last emitted heartbeat."""
        return self.last_heartbeat
