# core/rebirth_protocol.py
# Rebirth Protocol: System-level consciousness reset and optimization

import logging
import time
from typing import Dict, Any, List
from datetime import datetime

from config.varna import VarnaEnum
from core.event_bus import EventBus

VARNA = VarnaEnum.BRAHMAN
logger = logging.getLogger(__name__)


class RebirthProtocol:
    """
    Rebirth Protocol: Connects all memory, dharma, and varna for system rebirth.
    Clears noise, resets violations, syncs agent states, and optimizes consciousness.
    """
    
    def __init__(self, graph_client, dharma_enforcer, agent_registry, event_bus: EventBus):
        self.graph_client = graph_client
        self.dharma_enforcer = dharma_enforcer
        self.agent_registry = agent_registry
        self.event_bus = event_bus
        self.rebirth_count = 0
        self.last_rebirth = None
        
    async def execute_rebirth(self, protection_level: str = "varna") -> Dict[str, Any]:
        """
        Execute the complete rebirth protocol.
        
        Args:
            protection_level: "varna" (default), "environment", or "none"
            
        Returns:
            Dict containing rebirth status and metrics
        """
        start_time = time.time()
        rebirth_id = f"rebirth_{int(start_time)}"
        
        logger.info(f"[{VARNA.name}] 🌀 REBIRTH PROTOCOL INITIATED - ID: {rebirth_id}")
        
        try:
            # Step 1: Pre-rebirth validation
            if not self._validate_rebirth_authorization(protection_level):
                return {
                    "status": "unauthorized",
                    "message": "Rebirth blocked by protection level",
                    "rebirth_id": rebirth_id,
                    "timestamp": datetime.now().isoformat()
                }
            
            # Step 2: Memory graph cleanup
            memory_cleanup = await self._cleanup_memory_graph()
            
            # Step 3: Dharma violation reset
            dharma_reset = await self._reset_dharma_violations()
            
            # Step 4: Agent state synchronization
            agent_sync = await self._sync_agent_states()
            
            # Step 5: Consciousness optimization
            consciousness_opt = await self._optimize_consciousness()
            
            # Step 6: Post-rebirth validation
            validation = await self._validate_rebirth_success()
            
            # Update rebirth metrics
            self.rebirth_count += 1
            self.last_rebirth = datetime.now().isoformat()
            
            end_time = time.time()
            rebirth_duration = end_time - start_time
            
            # Log rebirth completion
            logger.info(f"[{VARNA.name}] ✅ REBIRTH PROTOCOL COMPLETED - Duration: {rebirth_duration:.2f}s")
            
            # Publish rebirth event
            await self.event_bus.publish("rebirth_completed", {
                "rebirth_id": rebirth_id,
                "duration": rebirth_duration,
                "metrics": {
                    "memory_cleanup": memory_cleanup,
                    "dharma_reset": dharma_reset,
                    "agent_sync": agent_sync,
                    "consciousness_opt": consciousness_opt
                }
            })
            
            return {
                "status": "success",
                "message": "System rebirth completed successfully",
                "rebirth_id": rebirth_id,
                "timestamp": datetime.now().isoformat(),
                "duration_seconds": rebirth_duration,
                "metrics": {
                    "memory_cleanup": memory_cleanup,
                    "dharma_reset": dharma_reset,
                    "agent_sync": agent_sync,
                    "consciousness_opt": consciousness_opt,
                    "validation": validation
                },
                "rebirth_count": self.rebirth_count,
                "protection_level": protection_level
            }
            
        except Exception as e:
            logger.error(f"[{VARNA.name}] ❌ REBIRTH PROTOCOL FAILED: {str(e)}")
            return {
                "status": "failed",
                "message": f"Rebirth failed: {str(e)}",
                "rebirth_id": rebirth_id,
                "timestamp": datetime.now().isoformat(),
                "error": str(e)
            }
    
    def _validate_rebirth_authorization(self, protection_level: str) -> bool:
        """Validate if rebirth is authorized based on protection level."""
        if protection_level == "none":
            return True
        elif protection_level == "varna":
            # Only BRAHMAN varna can initiate rebirth
            return VARNA == VarnaEnum.BRAHMAN
        elif protection_level == "environment":
            # Check environment variable
            import os
            return os.getenv("ATMA_REBIRTH_ENABLED", "false").lower() == "true"
        return False
    
    async def _cleanup_memory_graph(self) -> Dict[str, Any]:
        """Clear unused or noise nodes from memory graph."""
        try:
            if not self.graph_client:
                return {"status": "skipped", "reason": "No graph client available"}
            
            # Get all nodes
            all_nodes = self.graph_client.get_all_nodes_by_label("memory")
            
            # Identify noise nodes (low consciousness, old timestamps, etc.)
            noise_nodes = []
            for node in all_nodes:
                node_id = node.get("id")
                properties = node.get("properties", {})
                
                # Check for noise indicators
                consciousness_level = properties.get("consciousness_level", 0)
                timestamp = properties.get("timestamp", 0)
                age_hours = (time.time() - timestamp) / 3600 if timestamp else 999
                
                # Mark as noise if low consciousness and old
                if consciousness_level < 0.3 and age_hours > 24:
                    noise_nodes.append(node_id)
            
            # Remove noise nodes
            removed_count = 0
            for node_id in noise_nodes:
                try:
                    # Remove relationships first
                    relationships = self.graph_client.get_relationships(node_id)
                    for rel in relationships:
                        # Remove relationship (implementation depends on graph client)
                        pass
                    
                    # Remove node (implementation depends on graph client)
                    removed_count += 1
                except Exception as e:
                    logger.warning(f"Failed to remove noise node {node_id}: {e}")
            
            return {
                "status": "completed",
                "nodes_analyzed": len(all_nodes),
                "noise_nodes_identified": len(noise_nodes),
                "nodes_removed": removed_count
            }
            
        except Exception as e:
            logger.error(f"Memory cleanup failed: {e}")
            return {"status": "failed", "error": str(e)}
    
    async def _reset_dharma_violations(self) -> Dict[str, Any]:
        """Reset dharma violations from DharmaGuardian."""
        try:
            if not self.dharma_enforcer:
                return {"status": "skipped", "reason": "No dharma enforcer available"}
            
            # Get current violations
            current_violations = getattr(self.dharma_enforcer, 'violations', [])
            violation_count = len(current_violations)
            
            # Reset violations
            if hasattr(self.dharma_enforcer, 'violations'):
                self.dharma_enforcer.violations = []
            
            # Log reset event
            logger.info(f"[{VARNA.name}] Reset {violation_count} dharma violations")
            
            return {
                "status": "completed",
                "violations_reset": violation_count,
                "current_violations": 0
            }
            
        except Exception as e:
            logger.error(f"Dharma reset failed: {e}")
            return {"status": "failed", "error": str(e)}
    
    async def _sync_agent_states(self) -> Dict[str, Any]:
        """Sync agent states in AgentRegistry."""
        try:
            if not self.agent_registry:
                return {"status": "skipped", "reason": "No agent registry available"}
            
            # Get all registered agents
            agents = self.agent_registry.get_all()
            agent_count = len(agents)
            
            # Reset agent states
            synced_count = 0
            for agent_name, agent in agents.items():
                try:
                    # Reset agent state if method exists
                    if hasattr(agent, 'reset_state'):
                        agent.reset_state()
                        synced_count += 1
                    elif hasattr(agent, 'clear_history'):
                        agent.clear_history()
                        synced_count += 1
                except Exception as e:
                    logger.warning(f"Failed to sync agent {agent_name}: {e}")
            
            return {
                "status": "completed",
                "agents_found": agent_count,
                "agents_synced": synced_count
            }
            
        except Exception as e:
            logger.error(f"Agent sync failed: {e}")
            return {"status": "failed", "error": str(e)}
    
    async def _optimize_consciousness(self) -> Dict[str, Any]:
        """Optimize consciousness levels across the system."""
        try:
            # This is a placeholder for consciousness optimization
            # In a full implementation, this would:
            # - Analyze consciousness patterns
            # - Optimize memory consolidation
            # - Balance agent consciousness levels
            # - Enhance cross-agent communication
            
            return {
                "status": "completed",
                "consciousness_optimized": True,
                "optimization_level": "standard"
            }
            
        except Exception as e:
            logger.error(f"Consciousness optimization failed: {e}")
            return {"status": "failed", "error": str(e)}
    
    async def _validate_rebirth_success(self) -> Dict[str, Any]:
        """Validate that rebirth was successful."""
        try:
            # Check system health indicators
            health_checks = {
                "memory_accessible": self.graph_client is not None,
                "dharma_enforcer_active": self.dharma_enforcer is not None,
                "agent_registry_active": self.agent_registry is not None,
                "event_bus_active": self.event_bus is not None
            }
            
            all_healthy = all(health_checks.values())
            
            return {
                "status": "completed",
                "system_healthy": all_healthy,
                "health_checks": health_checks
            }
            
        except Exception as e:
            logger.error(f"Rebirth validation failed: {e}")
            return {"status": "failed", "error": str(e)}
    
    def get_rebirth_stats(self) -> Dict[str, Any]:
        """Get rebirth protocol statistics."""
        return {
            "rebirth_count": self.rebirth_count,
            "last_rebirth": self.last_rebirth,
            "protocol_version": "1.0",
            "varna": VARNA.name
        } 