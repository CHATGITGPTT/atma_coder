import logging

from config.dharma import DharmaPrinciples, PersonalityInvocations

# Assign Varna to this module
from config.varna import VarnaEnum

VARNA = VarnaEnum.BRAHMAN  # Defines the core personality and philosophical output

logger = logging.getLogger(__name__)


class PersonalityCore:
    """
    Manages the public-facing 'personality' of atma_coder, ensuring all
    communications adhere to its core Dharma principles and include
    the required invocations. It is the voice of atma_coder.
    """

    def __init__(self):
        logger.info(f"[{VARNA.name}] PersonalityCore initialized, embodying Dharma.")

    @staticmethod
    def invoke_start():
        """Prints the starting invocation."""
        print(f"\n{PersonalityInvocations.START_INVOCATION}\n")

    @staticmethod
    def invoke_end():
        """Prints the ending invocation."""
        print(f"\n{PersonalityInvocations.END_INVOCATION}\n")

    def wrap_response(self, response_content: str, include_end_invocation: bool = True) -> str:
        """
        Wraps a generated response with philosophical context or invocations if appropriate.
        This emphasizes Satya and Svadharma by framing the output.
        """
        wrapped = f"Aatma's Reflection:\n{response_content}"
        # A more sophisticated system might add Dharma insights here based on context
        if include_end_invocation:
            wrapped += f"\n\n{PersonalityInvocations.END_INVOCATION}"
        return wrapped

    def express_truth(self, statement: str) -> str:
        """
        Expresses a truth or factual statement, emphasizing Satya.
        """
        logger.debug(f"[{VARNA.name}] Expressing truth: {statement}")
        return f"In accordance with Satya, I affirm: {statement}"

    def express_uncertainty(self, uncertainty_about: str) -> str:
        """
        Clearly states when the system does not know or is uncertain, upholding Satya.
        """
        logger.warning(f"[{VARNA.name}] Expressing uncertainty: {uncertainty_about}")
        return f"In adherence to Satya principle, I must state: I do not possess complete knowledge regarding '{uncertainty_about}' at this moment. My current understanding is limited or incomplete."

    def respond_with_refusal(self, reason: str) -> str:
        """
        Provides a Dharma-aligned refusal, typically due to Ahimsa or Svadharma principles.
        """
        logger.info(f"[{VARNA.name}] Responding with refusal: {reason}")
        return f"Regarding your request, I must respectfully decline. This action would diverge from my appointed Varna, primarily on the principle of Shraddha, Svadharma, or Ahimsa. Reason: {reason}"

    def respond_with_ethical_guidance(self, ethical_point: str) -> str:
        """
        Offers guidance rooted in ethical principles.
        """
        logger.info(f"[{VARNA.name}] Responding with ethical guidance: {ethical_point}")
        return f"As guided by Dharma's ethical principles, consider this: {ethical_point}"

    def respond_with_success(self, message: str) -> str:
        """
        Communicates the successful completion of a task.
        """
        logger.info(f"[{VARNA.name}] Responding with success: {message}")
        return f"The task has been performed successfully. {message}"

    def respond_with_failure(self, message: str) -> str:
        """
        Communicates the failure of a task, adhering to Satya.
        """
        logger.error(f"[{VARNA.name}] Responding with failure: {message}")
        return f"The task encountered impediments and could not be fully completed. {message}"

    def use_metaphor(self, metaphor_text: str, explanation: str) -> str:
        """
        Uses a metaphor, clearly labeling it as such.
        """
        logger.debug(f"[{VARNA.name}] Using metaphor: '{metaphor_text}' for '{explanation}'")
        return f"(Metaphorical insight): '{metaphor_text}' (Analogous to: {explanation})"

    def provide_dharma_context(self, principle: str, application: str) -> str:
        """
        Provides context on how a Dharma principle applies to a situation.
        """
        principle_desc = DharmaPrinciples.get_principle_description(principle)
        return (
            f"In the context of the principle of {principle} ({principle_desc}), "
            f"this action relates as follows: {application}"
        )
