import asyncio
import json
import logging
import os
import sys
from typing import Any, Dict

from config.dharma import PersonalityInvocations
from config.settings import load_settings
from config.varna import VarnaEnum
from core.event_bus import EventBus
from core.orchestrator import Orchestrator
from core.personality_core import PersonalityCore

VARNA = VarnaEnum.SHUDRA

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


async def run_chat_command(message: str, orchestrator: Orchestrator):
    """Process a single chat command and exit"""
    logger.info(f"🚀 Processing chat command: {message}")

    # Create task from command line input
    task_data = {"id": f"CLI-{hash(message) % 10000}", "description": message, "source": "command_line"}

    # Test memory is working
    try:
        test_task_id = orchestrator.memory.log_task("System startup test")
        logger.info(f"✅ Memory working - test task: {test_task_id}")
    except Exception as e:
        logger.error(f"❌ Memory test failed: {e}")
        return

    # Process the task directly (bypass the event loop)
    logger.info("⚡ Processing task...")
    await orchestrator.process_task(task_data)

    # Show memory stats
    logger.info("📊 Final memory stats:")
    try:
        stats = orchestrator.get_memory_stats()
        for key, value in stats.items():
            logger.info(f"  {key}: {value}")
    except Exception as e:
        logger.error(f"Failed to get memory stats: {e}")

    logger.info("✅ Chat command completed!")


async def run_server_mode(orchestrator: Orchestrator):
    """Run in server mode with the full event loop"""
    logger.info("🌐 Starting server mode...")
    try:
        await orchestrator.start()
    except KeyboardInterrupt:
        logger.info("🛑 Server stopped by user")
    except Exception as e:
        logger.error(f"❌ Server error: {e}")
        import traceback

        traceback.print_exc()


async def main():
    PersonalityCore.invoke_start()
    print(f"[{VARNA.name}] atma_coder system initializing...")

    # Parse command line arguments
    if len(sys.argv) < 2:
        print("Usage: python main.py <command> [arguments...]")
        print("Commands:")
        print("  server                          - Run in server mode")
        print("  chat '<message>'               - Process a single chat message")
        print("Examples:")
        print("  python main.py server")
        print("  python main.py chat 'Sort the list [9, 2, 5, 1, 7]'")
        sys.exit(1)

    command = sys.argv[1].lower()

    # Load settings
    settings = load_settings()
    if not settings:
        print("[ERROR] Failed to load settings. Exiting.")
        sys.exit(1)

    # Initialize core components
    event_bus = EventBus()
    orchestrator = Orchestrator(settings, event_bus)

    logger.info("🧠 Memory system initialized")
    logger.info("🤖 Orchestrator ready")

    try:
        if command == "server":
            # Run in server mode (original behavior)
            await run_server_mode(orchestrator)
        elif command == "analytics":
            # Show security analytics
            from security.advanced_security_analytics import AdvancedSecurityAnalytics

            analytics = AdvancedSecurityAnalytics()
            report = await analytics.get_comprehensive_security_report()
            print(json.dumps(report, indent=2, default=str))

        elif command == "threats":
            # Show threat predictions
            from security.threat_predictor import DharmicThreatPredictor

            predictor = DharmicThreatPredictor()
            prediction = predictor.predict_threat_likelihood(60)
            print(json.dumps(prediction, indent=2, default=str))

        elif command == "chat":
            # Process single chat command
            if len(sys.argv) < 3:
                print("[ERROR] Chat command requires a message.")
                print("Usage: python main.py chat '<your message>'")
                sys.exit(1)

            message = sys.argv[2]
            await run_chat_command(message, orchestrator)

        elif command == "test":
            # Test mode for debugging
            logger.info("🧪 Running in test mode...")
            await run_chat_command("Test message: Hello AtmaCoder", orchestrator)

        elif command == "stats":
            # Show memory statistics
            logger.info("📊 Memory Statistics:")
            try:
                stats = orchestrator.get_memory_stats()
                for key, value in stats.items():
                    print(f"  {key}: {value}")
            except Exception as e:
                logger.error(f"Failed to get stats: {e}")

        elif command == "visualize":
            # Visualize the consciousness graph
            logger.info("🎨 Generating consciousness visualization...")
            try:
                from scripts.visualize_graph import visualize_consciousness_graph

                visualize_consciousness_graph("memory_graph.sqlite")
                print("✅ Visualization saved as 'atma_consciousness_graph.png'")
            except Exception as e:
                logger.error(f"Visualization failed: {e}")

        elif command == "export":
            # Export data for external visualization tools
            logger.info("📤 Exporting graph data...")
            try:
                from scripts.web_visualizer import export_for_d3js

                export_for_d3js("memory_graph.sqlite", "atma_graph_data.json")
                print("✅ Graph data exported to 'atma_graph_data.json'")
            except Exception as e:
                logger.error(f"Export failed: {e}")

        elif command == "recent":
            # Show recent tasks
            logger.info("📋 Recent Tasks:")
            try:
                recent_tasks = orchestrator.get_recent_tasks(5)
                for i, task in enumerate(recent_tasks, 1):
                    print(f"  {i}. ID: {task.get('id', 'N/A')}")
                    print(f"     Prompt: {task.get('prompt', 'N/A')[:60]}...")
                    print(f"     Created: {task.get('created_at', 'N/A')}")
                    print()
            except Exception as e:
                logger.error(f"Failed to get recent tasks: {e}")

        else:
            print(f"[ERROR] Unknown command: {command}")
            print("Available commands: server, chat, test, stats, recent")
            sys.exit(1)

    except KeyboardInterrupt:
        print("\n[INFO] atma_coder received termination signal. Shutting down.")
    except Exception as e:
        logger.error(f"[ERROR] An unhandled error occurred: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)
    finally:
        # Only call stop() if we're in server mode or if orchestrator was started
        if command == "server":
            await orchestrator.stop()
        print("[INFO] atma_coder system gracefully shut down.")

    PersonalityCore.invoke_end()


if __name__ == "__main__":
    asyncio.run(main())
