import ast
import json
import sqlite3
from pathlib import Path


def export_for_d3js(db_path="memory_graph.sqlite", output_file="graph_data.json"):
    """Export graph data for D3.js visualization"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    nodes = []
    links = []

    # Export nodes
    for row in cursor.execute("SELECT id, properties FROM nodes"):
        node_id, props_str = row
        try:
            props = ast.literal_eval(props_str)
            nodes.append(
                {
                    "id": node_id,
                    "label": props.get("label", "unknown"),
                    "group": props.get("label", "unknown"),
                    "properties": props,
                }
            )
        except BaseException:
            nodes.append({"id": node_id, "label": "unknown", "group": "unknown"})

    # Export edges
    for row in cursor.execute("SELECT src, type, dst FROM edges"):
        src, edge_type, dst = row
        links.append({"source": src, "target": dst, "type": edge_type, "value": 1})

    graph_data = {
        "nodes": nodes,
        "links": links,
        "metadata": {"total_nodes": len(nodes), "total_edges": len(links), "generated_at": "2025-07-22T01:11:00Z"},
    }

    with open(output_file, "w") as f:
        json.dump(graph_data, f, indent=2)

    print(f"Graph data exported to {output_file}")
    return graph_data
