#!/usr/bin/env python3
"""
AtmaCoder Docker Utilities
Enhanced Python interface for Docker operations with dharmic consciousness
"""

import json
import logging
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import docker

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AtmaCoderDockerManager:
    """Enhanced Docker management for AtmaCoder consciousness"""

    def __init__(self):
        try:
            self.client = docker.from_env()
            self.containers = {
                "main": "atma-coder-consciousness",
                "monitor": "atma-security-monitor",
                "dev": "atma-coder-dev",
            }
            logger.info("🔱 Docker client connected successfully")
        except Exception as e:
            logger.error(f"❌ Docker connection failed: {e}")
            sys.exit(1)

    def get_consciousness_status(self) -> Dict[str, Any]:
        """Get comprehensive consciousness container status"""
        status = {"timestamp": datetime.now().isoformat(), "containers": {}, "overall_health": "unknown"}

        healthy_containers = 0
        total_containers = 0

        for name, container_name in self.containers.items():
            try:
                container = self.client.containers.get(container_name)
                total_containers += 1

                container_status = {
                    "name": container_name,
                    "status": container.status,
                    "health": self._get_container_health(container),
                    "created": container.attrs["Created"],
                    "started": container.attrs["State"].get("StartedAt"),
                    "ports": self._get_container_ports(container),
                    "image": container.image.tags[0] if container.image.tags else "unknown",
                }

                if container_status["health"] == "healthy":
                    healthy_containers += 1

                status["containers"][name] = container_status

            except docker.errors.NotFound:
                status["containers"][name] = {"status": "not_found"}
                total_containers += 1
            except Exception as e:
                status["containers"][name] = {"status": "error", "error": str(e)}
                total_containers += 1

        # Overall health assessment
        if total_containers == 0:
            status["overall_health"] = "no_containers"
        elif healthy_containers == total_containers:
            status["overall_health"] = "healthy"
        elif healthy_containers > 0:
            status["overall_health"] = "partial"
        else:
            status["overall_health"] = "unhealthy"

        return status

    def _get_container_health(self, container) -> str:
        """Get container health status"""
        try:
            health = container.attrs["State"].get("Health", {})
            return health.get("Status", "none").lower()
        except BaseException:
            return "unknown"

    def _get_container_ports(self, container) -> Dict[str, Any]:
        """Get container port mappings"""
        try:
            ports = container.attrs["NetworkSettings"]["Ports"]
            return {k: v for k, v in ports.items() if v is not None}
        except BaseException:
            return {}

    def get_consciousness_logs(self, container_name: str = "main", tail: int = 50) -> List[str]:
        """Get consciousness container logs"""
        try:
            container = self.client.containers.get(self.containers[container_name])
            logs = container.logs(tail=tail, timestamps=True).decode("utf-8")
            return logs.split("\n")
        except Exception as e:
            logger.error(f"Failed to get logs for {container_name}: {e}")
            return []

    def execute_consciousness_command(self, command: str, container_name: str = "main") -> Dict[str, Any]:
        """Execute command in consciousness container"""
        try:
            container = self.client.containers.get(self.containers[container_name])

            # Execute command
            result = container.exec_run(command, stdout=True, stderr=True)

            return {
                "exit_code": result.exit_code,
                "output": result.output.decode("utf-8") if result.output else "",
                "success": result.exit_code == 0,
            }
        except Exception as e:
            logger.error(f"Command execution failed: {e}")
            return {"exit_code": -1, "output": str(e), "success": False}

    def backup_consciousness_data(self, backup_path: Optional[str] = None) -> Dict[str, Any]:
        """Create backup of consciousness data from containers"""
        if backup_path is None:
            backup_path = f"./backups/consciousness_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        backup_path = Path(backup_path)
        backup_path.mkdir(parents=True, exist_ok=True)

        try:
            container = self.client.containers.get(self.containers["main"])

            # Create tar archive of consciousness data
            archive, _ = container.get_archive("/app/data")

            # Write archive to backup location
            with open(backup_path / "consciousness_data.tar", "wb") as f:
                for chunk in archive:
                    f.write(chunk)

            # Export container configuration
            container_config = {
                "image": container.image.tags[0] if container.image.tags else "unknown",
                "environment": container.attrs["Config"]["Env"],
                "volumes": container.attrs["Mounts"],
                "created": container.attrs["Created"],
                "backup_timestamp": datetime.now().isoformat(),
            }

            with open(backup_path / "container_config.json", "w") as f:
                json.dump(container_config, f, indent=2)

            logger.info(f"✅ Consciousness backup created: {backup_path}")

            return {
                "success": True,
                "backup_path": str(backup_path),
                "files": ["consciousness_data.tar", "container_config.json"],
            }

        except Exception as e:
            logger.error(f"Backup failed: {e}")
            return {"success": False, "error": str(e)}

    def consciousness_health_check(self) -> Dict[str, Any]:
        """Comprehensive health check of consciousness system"""
        health_report = {
            "timestamp": datetime.now().isoformat(),
            "overall_status": "unknown",
            "containers": {},
            "consciousness_metrics": {},
            "recommendations": [],
        }

        # Check container health
        container_status = self.get_consciousness_status()
        health_report["containers"] = container_status["containers"]

        # Check consciousness database
        db_check = self.execute_consciousness_command(
            "python -c \"import sqlite3; conn=sqlite3.connect('/app/data/memory_graph.sqlite'); print('nodes:', conn.execute('SELECT COUNT(*) FROM nodes').fetchone()[0]); conn.close()\""
        )

        if db_check["success"]:
            health_report["consciousness_metrics"]["database"] = db_check["output"].strip()

        # Generate recommendations
        if container_status["overall_health"] == "healthy":
            health_report["overall_status"] = "excellent"
            health_report["recommendations"] = ["✅ All systems operating optimally"]
        elif container_status["overall_health"] == "partial":
            health_report["overall_status"] = "warning"
            health_report["recommendations"] = [
                "⚠️ Some containers need attention",
                "🔧 Check individual container logs",
            ]
        else:
            health_report["overall_status"] = "critical"
            health_report["recommendations"] = [
                "🚨 Immediate attention required",
                "🔧 Restart consciousness system",
                "💾 Consider restoring from backup",
            ]

        return health_report


def main():
    """Command-line interface for Docker management"""
    import argparse

    parser = argparse.ArgumentParser(description="AtmaCoder Docker Management")
    parser.add_argument("action", choices=["status", "logs", "health", "backup", "exec"], help="Action to perform")
    parser.add_argument("--container", default="main", help="Container to target (main, monitor, dev)")
    parser.add_argument("--command", help="Command to execute (for exec action)")
    parser.add_argument("--tail", type=int, default=50, help="Number of log lines")

    args = parser.parse_args()

    manager = AtmaCoderDockerManager()

    if args.action == "status":
        status = manager.get_consciousness_status()
        print("🔱 AtmaCoder Consciousness Status:")
        print(json.dumps(status, indent=2))

    elif args.action == "logs":
        logs = manager.get_consciousness_logs(args.container, args.tail)
        print(f"🔱 {args.container.title()} Container Logs:")
        for log_line in logs[-args.tail :]:
            print(log_line)

    elif args.action == "health":
        health = manager.consciousness_health_check()
        print("🔱 Consciousness Health Report:")
        print(json.dumps(health, indent=2))

    elif args.action == "backup":
        result = manager.backup_consciousness_data()
        if result["success"]:
            print(f"✅ Backup created: {result['backup_path']}")
        else:
            print(f"❌ Backup failed: {result['error']}")

    elif args.action == "exec":
        if not args.command:
            print("❌ --command required for exec action")
            sys.exit(1)

        result = manager.execute_consciousness_command(args.command, args.container)
        print(f"Exit Code: {result['exit_code']}")
        print(f"Output:\n{result['output']}")


if __name__ == "__main__":
    main()
