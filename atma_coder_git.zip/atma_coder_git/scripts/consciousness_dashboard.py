# scripts/consciousness_dashboard.py
import json
import sqlite3

from flask import Flask, jsonify, render_template

app = Flask(__name__)


@app.route("/")
def dashboard():
    return render_template("consciousness.html")


@app.route("/api/graph")
def get_graph_data():
    # Return live graph data
    return jsonify(export_for_d3js())


if __name__ == "__main__":
    app.run(debug=True, port=8108)
