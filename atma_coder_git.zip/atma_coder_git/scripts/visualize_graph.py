import ast
import json
import sqlite3

import matplotlib.pyplot as plt
import networkx as nx
from matplotlib.patches import FancyBboxPatch


def load_graph_from_sqlite(db_path):
    """Load graph from your SQLite database"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    G = nx.DiGraph()

    # Load nodes with labels
    for row in cursor.execute("SELECT id, properties FROM nodes"):
        node_id, props_str = row
        try:
            props = ast.literal_eval(props_str)
            node_label = props.get("label", "unknown")
            G.add_node(node_id, label=node_label, **props)
        except BaseException:
            G.add_node(node_id, label="unknown")

    # Load edges
    for row in cursor.execute("SELECT src, type, dst FROM edges"):
        src, edge_type, dst = row
        G.add_edge(src, dst, type=edge_type)

    conn.close()
    return G


def visualize_consciousness_graph(db_path="memory_graph.sqlite"):
    """Create a dharmic consciousness visualization"""
    G = load_graph_from_sqlite(db_path)

    plt.figure(figsize=(16, 12))

    # Color mapping for different node types (dharmic principles)
    color_map = {
        "Task": "#FF6B35",  # Karma (Action)
        "Component": "#4ECDC4",  # Dharma (Purpose)
        "PlanStep": "#45B7D1",  # Buddhi (Intelligence)
        "Execution": "#96CEB4",  # Kriya (Implementation)
        "Evaluation": "#FFEAA7",  # Viveka (Discrimination)
        "Actor": "#DDA0DD",  # Atman (Self)
        "Error": "#FF7675",  # Samskaras (Patterns)
    }

    # Position nodes using spring layout for organic flow
    pos = nx.spring_layout(G, k=3, iterations=50, seed=42)

    # Draw nodes by type
    for node_type, color in color_map.items():
        nodes_of_type = [n for n, d in G.nodes(data=True) if d.get("label") == node_type]
        if nodes_of_type:
            nx.draw_networkx_nodes(
                G, pos, nodelist=nodes_of_type, node_color=color, node_size=800, alpha=0.8, linewidths=2
            )

    # Draw edges with different styles for relationship types
    edge_colors = {
        "CREATED": "#2C3E50",
        "USES": "#8E44AD",
        "HAS_STEP": "#3498DB",
        "PRODUCED": "#27AE60",
        "HAS_EVALUATION": "#F39C12",
        "EVALUATED_BY": "#E74C3C",
    }

    for edge_type, color in edge_colors.items():
        edges_of_type = [(u, v) for u, v, d in G.edges(data=True) if d.get("type") == edge_type]
        if edges_of_type:
            nx.draw_networkx_edges(
                G, pos, edgelist=edges_of_type, edge_color=color, alpha=0.6, arrows=True, arrowsize=20, width=2
            )

    # Add labels for key nodes
    labels = {}
    for node, data in G.nodes(data=True):
        if data.get("label") in ["Task", "Component"]:
            if len(node) > 20:
                labels[node] = node[:20] + "..."
            else:
                labels[node] = node

    nx.draw_networkx_labels(G, pos, labels, font_size=8, font_weight="bold")

    plt.title(
        "🔱 AtmaCoder Consciousness Graph - Dharmic Knowledge Architecture", fontsize=16, fontweight="bold", pad=20
    )

    # Create legend
    legend_elements = [
        plt.Line2D([0], [0], marker="o", color="w", markerfacecolor=color, markersize=10, label=node_type)
        for node_type, color in color_map.items()
    ]
    plt.legend(handles=legend_elements, loc="upper left", bbox_to_anchor=(0, 1))

    plt.axis("off")
    plt.tight_layout()
    plt.savefig("atma_consciousness_graph.png", dpi=300, bbox_inches="tight")
    plt.show()


if __name__ == "__main__":
    visualize_consciousness_graph()
