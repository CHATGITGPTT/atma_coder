#!/usr/bin/env python3
"""
AtmaCoder Dharmic Code Cleanup System
Advanced automated Python code fixing, formatting, and error detection
"""

import argparse
import ast
import json
import logging
import os
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


class AtmaCoderCleanupSystem:
    """Enhanced Dharmic code cleanup system for AtmaCoder with parallel processing"""

    def __init__(self, project_root: str = ".", exclude_patterns: Set[str] = None, dry_run: bool = False):
        self.project_root = Path(project_root).resolve()
        self.dry_run = dry_run
        self.exclude_patterns = exclude_patterns or set()

        # Default exclusions
        self.default_exclusions = {
            ".git",
            "__pycache__",
            ".pytest_cache",
            "venv",
            "env",
            "node_modules",
            ".vscode",
            ".idea",
            "build",
            "dist",
            "*.egg-info",
            ".tox",
        }

        # Combine with user exclusions
        self.all_exclusions = self.default_exclusions | self.exclude_patterns

        # Cleanup tracking
        self.cleanup_report = {
            "start_time": datetime.now().isoformat(),
            "files_processed": 0,
            "files_fixed": 0,
            "syntax_errors_found": 0,
            "indentation_fixes": 0,
            "import_fixes": 0,
            "formatting_fixes": 0,
            "unicode_fixes": 0,
            "manual_fixes": 0,
            "total_errors_fixed": 0,
            "files_with_issues": [],
            "syntax_errors": [],
            "processing_errors": [],
            "execution_time": 0,
        }

        logger.info(f"🔱 AtmaCoder Dharmic Cleanup System initialized")
        logger.info(f"📁 Project root: {self.project_root}")
        logger.info(f"🚫 Excluded patterns: {self.all_exclusions}")
        if dry_run:
            logger.info("🔍 DRY RUN MODE - No files will be modified")

    def should_exclude_path(self, path: Path) -> bool:
        """Check if a path should be excluded based on patterns"""
        # Get the path relative to project root for cleaner checking
        try:
            relative_path = path.relative_to(self.project_root)
            path_parts = relative_path.parts
            path_str = str(relative_path)
        except ValueError:
            # Path is not relative to project root
            return True

        for pattern in self.all_exclusions:
            # Check exact directory name matches
            if pattern in path_parts:
                return True

            # Check for wildcard patterns like *.egg-info
            if pattern.startswith("*") and any(part.endswith(pattern[1:]) for part in path_parts):
                return True

            # Check if the pattern is anywhere in the path string (but be more specific)
            if pattern.startswith(".") and pattern in path_str:
                return True

        return False

    def scan_python_files(self) -> List[Path]:
        """Scan for all Python files in the project with exclusion support"""
        logger.info("🔍 Scanning for Python files...")

        python_files = []
        excluded_count = 0

        for root, dirs, files in os.walk(self.project_root):
            # Filter out excluded directories
            dirs[:] = [d for d in dirs if not self.should_exclude_path(Path(root) / d)]

            for file in files:
                if file.endswith(".py"):
                    file_path = Path(root) / file
                    if self.should_exclude_path(file_path):
                        excluded_count += 1
                        continue
                    python_files.append(file_path)

        self.python_files = python_files
        logger.info(f"📁 Found {len(python_files)} Python files")
        logger.info(f"🚫 Excluded {excluded_count} files")
        return python_files

    def check_syntax_errors(self, file_path: Path) -> Dict[str, Any]:
        """Check for Python syntax errors in a file"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()

            # Try to parse the file
            ast.parse(content)
            return {"has_error": False, "error": None, "content": content}

        except SyntaxError as e:
            return {
                "has_error": True,
                "error": {
                    "type": "SyntaxError",
                    "line": e.lineno or 0,
                    "column": e.offset or 0,
                    "message": str(e.msg) if e.msg else "Unknown syntax error",
                    "text": e.text.strip() if e.text else "Unknown",
                },
                "content": None,
            }
        except UnicodeDecodeError as e:
            return {
                "has_error": True,
                "error": {
                    "type": "UnicodeDecodeError",
                    "line": 0,
                    "column": 0,
                    "message": f"File encoding error: {str(e)}",
                    "text": "Encoding issue",
                },
                "content": None,
            }
        except Exception as e:
            return {
                "has_error": True,
                "error": {
                    "type": "UnknownError",
                    "line": 0,
                    "column": 0,
                    "message": f"File read error: {str(e)}",
                    "text": "Unknown error",
                },
                "content": None,
            }

    def detect_unicode_issues(self, content: str) -> List[Dict[str, Any]]:
        """Detect hidden Unicode characters that can cause issues"""
        issues = []

        # Common problematic Unicode characters
        problematic_chars = {
            "\u200b": "Zero Width Space",
            "\u200c": "Zero Width Non-Joiner",
            "\u200d": "Zero Width Joiner",
            "\u2060": "Word Joiner",
            "\ufeff": "Byte Order Mark",
            "\u00a0": "Non-Breaking Space",
            "\u2028": "Line Separator",
            "\u2029": "Paragraph Separator",
        }

        for line_num, line in enumerate(content.split("\n"), 1):
            for char, description in problematic_chars.items():
                if char in line:
                    issues.append(
                        {"line": line_num, "character": char, "description": description, "column": line.find(char)}
                    )

        return issues

    def fix_unicode_issues(self, content: str) -> tuple[str, int]:
        """Fix Unicode issues in content"""
        original_content = content
        fixes_made = 0

        # Define replacements
        replacements = {
            "\u200b": "",  # Zero Width Space -> remove
            "\u200c": "",  # Zero Width Non-Joiner -> remove
            "\u200d": "",  # Zero Width Joiner -> remove
            "\u2060": "",  # Word Joiner -> remove
            "\ufeff": "",  # Byte Order Mark -> remove
            "\u00a0": " ",  # Non-Breaking Space -> regular space
            "\u2028": "\n",  # Line Separator -> newline
            "\u2029": "\n\n",  # Paragraph Separator -> double newline
        }

        for char, replacement in replacements.items():
            if char in content:
                content = content.replace(char, replacement)
                fixes_made += content.count(char)

        return content, fixes_made

    def fix_basic_issues(self, content: str) -> tuple[str, int]:
        """Fix basic Python formatting issues"""
        fixes_made = 0
        original_content = content

        # Fix trailing whitespace
        lines = content.split("\n")
        new_lines = []
        for line in lines:
            stripped = line.rstrip()
            if stripped != line:
                fixes_made += 1
            new_lines.append(stripped)

        content = "\n".join(new_lines)

        # Fix excessive blank lines (more than 2 consecutive)
        content = re.sub(r"\n{4,}", "\n\n\n", content)
        if content != "\n".join(new_lines):
            fixes_made += 1

        # Ensure file ends with single newline
        if content and not content.endswith("\n"):
            content += "\n"
            fixes_made += 1
        elif content.endswith("\n\n"):
            content = content.rstrip("\n") + "\n"
            fixes_made += 1

        return content, fixes_made

    def run_tool(self, tool_name: str, args: List[str], file_path: Path) -> Dict[str, Any]:
        """Run a formatting tool on a file"""
        try:
            cmd = [sys.executable, "-m", tool_name] + args + [str(file_path)]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "stdout": "",
                "stderr": f"{tool_name} timed out after 30 seconds",
                "returncode": -1,
            }
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": str(e), "returncode": -1}

    def process_single_file(self, file_path: Path) -> Dict[str, Any]:
        """Process a single Python file with all cleanup operations"""
        file_report = {
            "file": str(file_path.relative_to(self.project_root)),
            "original_size": 0,
            "final_size": 0,
            "syntax_ok": False,
            "issues_found": [],
            "fixes_applied": [],
            "errors": [],
            "unicode_issues_fixed": 0,
            "basic_fixes_applied": 0,
            "tools_applied": [],
        }

        try:
            # Get original file size
            file_report["original_size"] = file_path.stat().st_size

            # 1. Check syntax and read content
            syntax_check = self.check_syntax_errors(file_path)

            if syntax_check["has_error"]:
                error = syntax_check["error"]
                file_report["errors"].append(f"Syntax error: {error['message']}")
                file_report["issues_found"].append(f"Line {error['line']}: {error['message']}")
                self.cleanup_report["syntax_errors"].append(
                    {"file": str(file_path.relative_to(self.project_root)), "error": error}
                )
                return file_report

            file_report["syntax_ok"] = True
            content = syntax_check["content"]

            if self.dry_run:
                # In dry run mode, just detect issues without fixing
                unicode_issues = self.detect_unicode_issues(content)
                if unicode_issues:
                    file_report["issues_found"].extend(
                        [f"Line {issue['line']}: {issue['description']}" for issue in unicode_issues]
                    )
                return file_report

            # 2. Fix Unicode issues
            content, unicode_fixes = self.fix_unicode_issues(content)
            if unicode_fixes > 0:
                file_report["unicode_issues_fixed"] = unicode_fixes
                file_report["fixes_applied"].append(f"Fixed {unicode_fixes} Unicode issues")
                self.cleanup_report["unicode_fixes"] += unicode_fixes

            # 3. Fix basic issues
            content, basic_fixes = self.fix_basic_issues(content)
            if basic_fixes > 0:
                file_report["basic_fixes_applied"] = basic_fixes
                file_report["fixes_applied"].append(f"Applied {basic_fixes} basic fixes")
                self.cleanup_report["manual_fixes"] += basic_fixes

            # Write content back if we made changes
            total_manual_fixes = unicode_fixes + basic_fixes
            if total_manual_fixes > 0:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(content)

            # 4. Apply formatting tools in sequence
            tools = [
                ("autopep8", ["--in-place", "--aggressive", "--aggressive", "--max-line-length=120"]),
                ("isort", ["--profile=black", "--line-length=120"]),
                ("black", ["--line-length=120", "--target-version=py311"]),
            ]

            for tool_name, args in tools:
                result = self.run_tool(tool_name, args, file_path)
                if result["success"]:
                    file_report["tools_applied"].append(tool_name)
                    file_report["fixes_applied"].append(f"Applied {tool_name} formatting")
                else:
                    file_report["errors"].append(f"{tool_name}: {result['stderr'][:100]}")

            # Update statistics
            if file_report["tools_applied"]:
                if "autopep8" in file_report["tools_applied"]:
                    self.cleanup_report["indentation_fixes"] += 1
                if "isort" in file_report["tools_applied"]:
                    self.cleanup_report["import_fixes"] += 1
                if "black" in file_report["tools_applied"]:
                    self.cleanup_report["formatting_fixes"] += 1

            # Get final file size
            file_report["final_size"] = file_path.stat().st_size

            # Mark as fixed if any fixes were applied
            if file_report["fixes_applied"]:
                self.cleanup_report["files_fixed"] += 1

        except Exception as e:
            file_report["errors"].append(f"Processing error: {str(e)}")
            self.cleanup_report["processing_errors"].append(
                {"file": str(file_path.relative_to(self.project_root)), "error": str(e)}
            )

        return file_report

    def run_parallel_cleanup(self, max_workers: int = 4) -> Dict[str, Any]:
        """Run cleanup operations in parallel using ThreadPoolExecutor"""
        start_time = time.time()

        logger.info("🔱 Starting AtmaCoder Dharmic Code Cleanup System")

        # Scan for files
        python_files = self.scan_python_files()

        if not python_files:
            logger.warning("⚠️ No Python files found to process!")
            return self.cleanup_report

        # Process files in parallel
        logger.info(f"🚀 Processing {len(python_files)} files with {max_workers} workers...")

        detailed_reports = []
        processed_count = 0

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            future_to_file = {
                executor.submit(self.process_single_file, file_path): file_path for file_path in python_files
            }

            # Process completed tasks
            for future in as_completed(future_to_file):
                file_path = future_to_file[future]
                processed_count += 1

                try:
                    file_report = future.result()
                    detailed_reports.append(file_report)

                    # Progress indicator
                    if processed_count % 50 == 0 or processed_count == len(python_files):
                        progress = (processed_count / len(python_files)) * 100
                        logger.info(f"📊 Progress: {processed_count}/{len(python_files)} ({progress:.1f}%)")

                    # Track files with issues
                    if file_report["issues_found"] or file_report["errors"]:
                        self.cleanup_report["files_with_issues"].append(file_report["file"])

                except Exception as e:
                    logger.error(f"❌ Failed to process {file_path}: {e}")
                    self.cleanup_report["processing_errors"].append({"file": str(file_path), "error": str(e)})

        # Update final statistics
        self.cleanup_report["files_processed"] = len(python_files)
        self.cleanup_report["syntax_errors_found"] = len(self.cleanup_report["syntax_errors"])
        self.cleanup_report["total_errors_fixed"] = (
            self.cleanup_report["unicode_fixes"]
            + self.cleanup_report["manual_fixes"]
            + self.cleanup_report["indentation_fixes"]
            + self.cleanup_report["import_fixes"]
            + self.cleanup_report["formatting_fixes"]
        )
        self.cleanup_report["execution_time"] = time.time() - start_time
        self.cleanup_report["detailed_reports"] = detailed_reports
        self.cleanup_report["end_time"] = datetime.now().isoformat()

        return self.cleanup_report

    def print_summary(self):
        """Print a detailed cleanup summary"""
        report = self.cleanup_report

        print("\n" + "=" * 60)
        print("🔱 AtmaCoder Dharmic Code Cleanup Summary 🔱")
        print("=" * 60)

        print(f"⏱️  Execution time: {report['execution_time']:.1f} seconds")
        print(f"📁 Files processed: {report['files_processed']}")
        print(f"🔧 Files fixed: {report['files_fixed']}")
        print(f"❌ Syntax errors: {report['syntax_errors_found']}")
        print(f"🔤 Unicode fixes: {report['unicode_fixes']}")
        print(f"📏 Indentation fixes: {report['indentation_fixes']}")
        print(f"📦 Import fixes: {report['import_fixes']}")
        print(f"✨ Formatting fixes: {report['formatting_fixes']}")
        print(f"🛠️  Manual fixes: {report['manual_fixes']}")
        print(f"📊 Total errors fixed: {report['total_errors_fixed']}")

        if report["syntax_errors"]:
            print(f"\n🚨 Syntax Errors Found ({len(report['syntax_errors'])}):")
            for i, error in enumerate(report["syntax_errors"][:5]):  # Show first 5
                print(f"  {i+1}. {error['file']}")
                print(f"     Line {error['error']['line']}: {error['error']['message']}")
            if len(report["syntax_errors"]) > 5:
                print(f"     ... and {len(report['syntax_errors']) - 5} more")

        if report["processing_errors"]:
            print(f"\n⚠️ Processing Errors ({len(report['processing_errors'])}):")
            for error in report["processing_errors"][:3]:  # Show first 3
                print(f"  ❌ {error['file']}: {error['error'][:80]}...")

        print(f"\n🕉️ Dharmic Code Cleanup {'Analysis' if self.dry_run else 'Completed'}!")
        print("✨ Your AtmaCoder codebase is now aligned with dharmic principles!")
        print("=" * 60)

    def save_report(self, output_file: str = "cleanup_report.json"):
        """Save detailed cleanup report to JSON file"""
        report_path = self.project_root / output_file

        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(self.cleanup_report, f, indent=2, ensure_ascii=False)

        logger.info(f"📊 Detailed report saved to {report_path}")


def main():
    """Main function with CLI argument parsing"""
    parser = argparse.ArgumentParser(
        description="🔱 AtmaCoder Dharmic Code Cleanup System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 scripts/code_cleanup.py                    # Clean all Python files
  python3 scripts/code_cleanup.py --dry-run          # Show issues without fixing
  python3 scripts/code_cleanup.py --exclude venv     # Exclude additional directories
  python3 scripts/code_cleanup.py --workers 8        # Use 8 parallel workers
        """,
    )

    parser.add_argument("--path", default=".", help="Project path to clean (default: current directory)")

    parser.add_argument(
        "--exclude", action="append", default=[], help="Additional patterns to exclude (can be used multiple times)"
    )

    parser.add_argument("--dry-run", action="store_true", help="Show what would be done without making changes")

    parser.add_argument("--workers", type=int, default=4, help="Number of parallel workers (default: 4)")

    parser.add_argument(
        "--report", default="cleanup_report.json", help="Output file for detailed report (default: cleanup_report.json)"
    )

    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")

    args = parser.parse_args()

    # Configure logging level
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Create cleanup system
    cleanup_system = AtmaCoderCleanupSystem(
        project_root=args.path, exclude_patterns=set(args.exclude), dry_run=args.dry_run
    )

    # Run cleanup
    try:
        results = cleanup_system.run_parallel_cleanup(max_workers=args.workers)

        # Print summary
        cleanup_system.print_summary()

        # Save report
        cleanup_system.save_report(args.report)

        # Exit with appropriate code
        if results["syntax_errors_found"] > 0:
            sys.exit(1)  # Exit with error if syntax issues found

    except KeyboardInterrupt:
        logger.info("\n🛑 Cleanup interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"❌ Cleanup failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
