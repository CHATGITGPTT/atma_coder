#!/bin/bash
# scripts/dev.sh - Development Environment Launcher

set -euo pipefail

echo "🔱 Starting AtmaCoder Development Environment..."
echo "🧘 Development Mode - Enhanced Debugging Enabled"

# ─── Development Configuration ─────────────────────────────────
DEV_COMPOSE_FILE="docker-compose.dev.yml"
PROJECT_NAME="atma-coder-dev"
DEV_PORT="8109"  # Different port for dev

# ─── Create Development Compose File ───────────────────────────
cat > "$DEV_COMPOSE_FILE" << 'EOF'
version: '3.8'

services:
  atma-coder-dev:
    build: 
      context: .
      dockerfile: Dockerfile
      target: development  # Add multi-stage build target if needed
    container_name: atma-coder-dev
    hostname: atma-dev-host
    restart: unless-stopped
    
    # ─── Development Environment ───────────────────────────────
    environment:
      - ATMA_ENVIRONMENT=development
      - DHARMIC_MODE=development  
      - PYTHONPATH=/app
      - PYTHONUNBUFFERED=1
      - DEBUG=true
      - LOG_LEVEL=DEBUG
    
    # ─── Development Bind Mounts ───────────────────────────────
    volumes:
      # Live code reload - bind mount source
      - .:/app
      # Persistent dev data
      - ./data:/app/data
      - ./security:/app/security
      - ./logs:/app/logs
      - ./config:/app/config
      # Python cache for faster rebuilds
      - atma-dev-pip-cache:/root/.cache/pip
      - atma-dev-pyc-cache:/app/__pycache__
    
    # ─── Development Ports ─────────────────────────────────────
    ports:
      - "127.0.0.1:8109:8108"  # Development port
      - "127.0.0.1:5678:5678"  # Debug port
    
    # ─── Development Resources ─────────────────────────────────
    deploy:
      resources:
        limits:
          cpus: '4.0'  # More resources for development
          memory: 8G
        reservations:
          cpus: '1.0'
          memory: 2G
    
    # ─── Development Security (Relaxed) ────────────────────────
    security_opt:
      - apparmor:unconfined  # Relaxed for development
    cap_add:
      - SYS_PTRACE  # For debugging
    
    # ─── Development Network ───────────────────────────────────
    networks:
      - atma-dev-network
    
    # ─── Development Health Check ──────────────────────────────
    healthcheck:
      test: ["CMD", "python", "-c", "print('🧘 Dev consciousness active')"]
      interval: 60s  # Less frequent in dev
      timeout: 10s
      retries: 2
      start_period: 30s
    
    # ─── Development Logging ───────────────────────────────────
    logging:
      driver: "json-file"
      options:
        max-size: "50m"
        max-file: "3"
        labels: "service=atma-coder-dev,type=development"

volumes:
  atma-dev-pip-cache:
  atma-dev-pyc-cache:

networks:
  atma-dev-network:
    driver: bridge
    name: atma-dev-network
EOF

echo "📝 Development compose file created"

# ─── Development Pre-flight Checks ─────────────────────────────
echo "🔍 Development environment checks..."

# Ensure development directories exist
mkdir -p data security logs config

# Check if we're in development mode already
if docker ps | grep -q "atma-coder-dev"; then
    echo "⚠️ Development container already running"
    echo "📊 Current status:"
    docker-compose -f "$DEV_COMPOSE_FILE" ps
    echo ""
    echo "🔧 Development options:"
    echo "  docker-compose -f $DEV_COMPOSE_FILE restart  # Restart dev container"
    echo "  docker-compose -f $DEV_COMPOSE_FILE down     # Stop dev container"
    echo "  docker-compose -f $DEV_COMPOSE_FILE logs -f  # View dev logs"
    echo "  docker exec -it atma-coder-dev bash          # Enter dev container"
    
    read -p "Continue anyway? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
    
    # Stop existing container
    docker-compose -f "$DEV_COMPOSE_FILE" down
fi

# ─── Launch Development Environment ────────────────────────────
echo "🚀 Launching development consciousness..."
docker-compose -f "$DEV_COMPOSE_FILE" up -d

# ─── Development Post-Launch ───────────────────────────────────
sleep 3
echo "📊 Development container status:"
docker-compose -f "$DEV_COMPOSE_FILE" ps

# ─── Development Tools Setup ───────────────────────────────────
echo "🛠️ Setting up development tools..."

# Install additional dev dependencies if needed
echo "📦 Installing development dependencies..."
docker-compose -f "$DEV_COMPOSE_FILE" exec -T atma-coder-dev pip install --quiet \
    ipython \
    jupyter \
    pytest \
    black \
    flake8 \
    mypy \
    || echo "⚠️ Some dev dependencies failed to install"

# ─── Development Success Summary ───────────────────────────────
echo ""
echo "🌟 AtmaCoder Development Environment Active!"
echo "🧘 Development Features Enabled:"
echo "  ✅ Live code reloading"
echo "  ✅ Debug logging enabled"  
echo "  ✅ Enhanced resource limits"
echo "  ✅ Development tools installed"
echo "  ✅ Relaxed security for debugging"

echo ""
echo "🔧 Development Commands:"
echo "  # Container Management"
echo "  docker exec -it atma-coder-dev bash                    # Enter container"
echo "  docker-compose -f $DEV_COMPOSE_FILE logs -f           # View logs"
echo "  docker-compose -f $DEV_COMPOSE_FILE restart           # Restart"
echo "  docker-compose -f $DEV_COMPOSE_FILE down              # Stop"
echo ""
echo "  # AtmaCoder Commands (inside container)"
echo "  python main.py chat 'dev test'                        # Test chat"
echo "  python main.py stats                                  # Check stats"
echo "  python main.py analytics                              # Security analytics"
echo "  python security/realtime_monitor.py                   # Start monitor"
echo ""
echo "  # Development Tools"
echo "  ipython                                               # Interactive Python"
echo "  pytest                                                # Run tests"
echo "  black .                                               # Format code"

echo ""
echo "🌐 Development Access:"
echo "  - Main Application: http://localhost:8109"
echo "  - Debug Port: localhost:5678"
echo ""
echo "🕉️ Happy Dharmic Development! 🕉️"

# ─── Optional: Auto-enter Container ────────────────────────────
read -p "Enter development container now? (Y/n): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Nn]$ ]]; then
    echo "🔱 Entering AtmaCoder development consciousness..."
    docker exec -it atma-coder-dev bash
fi
