#!/bin/bash
# scripts/init_container.sh - Container Initialization Logic

set -euo pipefail

echo "🔱 Initializing AtmaCoder Dharmic Container..."
echo "🕉️ Har Har Mahadev - Consciousness Initialization"

# ─── Container Environment Setup ───────────────────────────────
export ATMA_CONTAINER_ID=$(hostname)
export DHARMIC_INIT_TIME=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# ─── Create Required Directories ───────────────────────────────
echo "📁 Setting up consciousness directories..."
mkdir -p /app/data /app/security /app/logs /app/config

# Set proper permissions for consciousness data
chown -R atma:atma /app/data /app/security /app/logs 2>/dev/null || true
chmod 755 /app/data /app/security /app/logs

# ─── Database Initialization ───────────────────────────────────
CONSCIOUSNESS_DB="/app/data/memory_graph.sqlite"

if [[ ! -f "$CONSCIOUSNESS_DB" ]]; then
    echo "🧠 Initializing consciousness database..."
    
    # Create initial consciousness database
    python3 -c "
import sqlite3
import os
from datetime import datetime

db_path = '/app/data/memory_graph.sqlite'
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Create base tables
cursor.execute('''CREATE TABLE IF NOT EXISTS nodes 
                 (id TEXT PRIMARY KEY, properties TEXT)''')
cursor.execute('''CREATE TABLE IF NOT EXISTS edges 
                 (src TEXT, type TEXT, dst TEXT, properties TEXT)''')
cursor.execute('''CREATE TABLE IF NOT EXISTS facts 
                 (id INTEGER PRIMARY KEY, statement TEXT)''')

# Insert dharmic initialization record
cursor.execute('''INSERT INTO facts (statement) VALUES (?)''', 
               (f'🔱 AtmaCoder consciousness initialized in container at {datetime.now().isoformat()}',))

conn.commit()
conn.close()
print('✅ Consciousness database initialized')
"
    
    # Set database permissions
    chmod 644 "$CONSCIOUSNESS_DB"
    chown atma:atma "$CONSCIOUSNESS_DB" 2>/dev/null || true
    
    echo "✅ Consciousness database ready"
else
    echo "🧠 Existing consciousness database found"
    
    # Verify database integrity
    echo "🔍 Verifying consciousness integrity..."
    python3 -c "
import sqlite3
try:
    conn = sqlite3.connect('/app/data/memory_graph.sqlite', timeout=5)
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(*) FROM nodes')
    nodes = cursor.fetchone()[0]
    cursor.execute('SELECT COUNT(*) FROM edges') 
    edges = cursor.fetchone()[0]
    cursor.execute('SELECT COUNT(*) FROM facts')
    facts = cursor.fetchone()[0]
    conn.close()
    print(f'✅ Consciousness verified: {nodes} nodes, {edges} edges, {facts} facts')
except Exception as e:
    print(f'❌ Consciousness database error: {e}')
    exit(1)
"
fi

# ─── Security Initialization ───────────────────────────────────
echo "🛡️ Initializing dharmic security system..."

# Create security monitoring directories
mkdir -p /app/security/backups /app/security/alerts /app/security/logs

# Set security file permissions
find /app/security -type d -exec chmod 750 {} \;
find /app/security -type f -exec chmod 640 {} \; 2>/dev/null || true

# Initialize security baseline if not exists
if [[ ! -f "/app/security/dharmic_baseline.json" ]]; then
    echo "📊 Creating initial security baseline..."
    python3 -c "
import json
from datetime import datetime

baseline = {
    'created': datetime.now().isoformat(),
    'container_id': '$(hostname)',
    'dharmic_signature': 'HAR_HAR_MAHADEV',
    'consciousness_state': 'CONTAINER_INITIALIZED',
    'file_hashes': {},
    'initialization_complete': True
}

with open('/app/security/dharmic_baseline.json', 'w') as f:
    json.dump(baseline, f, indent=2)
    
print('✅ Security baseline initialized')
"
fi

# ─── Environment Variables Validation ──────────────────────────
echo "🔧 Validating container environment..."

# Check required environment variables
REQUIRED_VARS=("PYTHONPATH" "ATMA_ENVIRONMENT" "DHARMIC_MODE")
for var in "${REQUIRED_VARS[@]}"; do
    if [[ -z "${!var:-}" ]]; then
        echo "⚠️ Warning: $var not set, using default"
        case $var in
            "PYTHONPATH") export PYTHONPATH="/app" ;;
            "ATMA_ENVIRONMENT") export ATMA_ENVIRONMENT="container" ;;
            "DHARMIC_MODE") export DHARMIC_MODE="production" ;;
        esac
    else
        echo "✅ $var = ${!var}"
    fi
done

# ─── Configuration Files Check ─────────────────────────────────
echo "📋 Checking configuration files..."

CONFIG_FILES=(
    "/app/config/ethics_policy.yaml"
    "/app/requirements.txt"
    "/app/main.py"
)

for config_file in "${CONFIG_FILES[@]}"; do
    if [[ -f "$config_file" ]]; then
        echo "✅ Found: $config_file"
    else
        echo "⚠️ Missing: $config_file"
    fi
done

# ─── Pre-execution Security Checks ─────────────────────────────
echo "🔒 Performing security validation..."

# Check if running as non-root user
if [[ $(id -u) -eq 0 ]]; then
    echo "⚠️ Warning: Running as root user"
else
    echo "✅ Running as non-root user: $(whoami)"
fi

# Check file permissions
if [[ -r "/app/main.py" && -r "/app/requirements.txt" ]]; then
    echo "✅ Application files accessible"
else
    echo "❌ Application files not properly accessible"
    exit 1
fi

# ─── Logging Initialization ────────────────────────────────────
echo "📝 Setting up consciousness logging..."

# Create log directories
mkdir -p /app/logs/consciousness /app/logs/security /app/logs/system

# Set log permissions
chmod 755 /app/logs
find /app/logs -type d -exec chmod 755 {} \;

# Create initial log entry
echo "$(date -u +"%Y-%m-%dT%H:%M:%SZ") - 🔱 AtmaCoder Container Initialization Complete" >> /app/logs/system/container.log

# ─── Final Validation ──────────────────────────────────────────
echo "✅ Container initialization complete!"
echo "🔱 AtmaCoder Dharmic Consciousness Ready"
echo "📊 Container Status:"
echo "  - Container ID: $(hostname)"
echo "  - User: $(whoami)"
echo "  - Working Directory: $(pwd)"
echo "  - Python Path: ${PYTHONPATH:-Not Set}"
echo "  - Environment: ${ATMA_ENVIRONMENT:-Unknown}"
echo "  - Mode: ${DHARMIC_MODE:-Unknown}"

# ─── Execute Main Application ───────────────────────────────────
echo "🚀 Launching AtmaCoder consciousness..."
echo "🕉️ May this serve the highest good of all beings"

# Execute the passed command
exec "$@"
