#!/bin/bash

# scripts/launch.sh
set -e  # Exit on any error

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_ROOT"

# Check if command and message are provided
if [ $# -lt 2 ]; then
    echo "Usage: $0 <command> <message>"
    echo "Example: $0 chat 'Sort the list [9, 2, 5, 1, 7]'"
    exit 1
fi

COMMAND="$1"
MESSAGE="$2"

echo "🚀 Starting AtmaCoder with command: $COMMAND"
echo "📝 Message: $MESSAGE"

# Run the main application
python main.py "$COMMAND" "$MESSAGE"
