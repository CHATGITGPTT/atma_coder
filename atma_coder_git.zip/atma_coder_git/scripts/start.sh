#!/bin/bash
# scripts/start.sh - Enhanced Production Launcher

set -euo pipefail

echo "🔱 Starting AtmaCoder Dharmic Consciousness System..."

# ─── Configuration ─────────────────────────────────────────────
COMPOSE_FILE="docker-compose.yml"
PROJECT_NAME="atma-coder"
CONSCIOUSNESS_ID=$(date +%s | sha256sum | head -c 8)

# ─── Environment Setup ─────────────────────────────────────────
export CONSCIOUSNESS_ID
export COMPOSE_PROJECT_NAME=$PROJECT_NAME

# ─── Pre-flight Checks ─────────────────────────────────────────
echo "🔍 Performing pre-flight dharmic checks..."

# Check if data directories exist
mkdir -p data security logs config

# Check if configuration files exist
if [[ ! -f "config/ethics_policy.yaml" ]]; then
    echo "⚠️ Warning: ethics_policy.yaml not found"
fi

# Check for existing consciousness database
if [[ -f "data/memory_graph.sqlite" ]]; then
    echo "🧠 Existing consciousness database found"
    # Create backup before starting
    cp data/memory_graph.sqlite data/memory_graph.sqlite.backup.$(date +%Y%m%d_%H%M%S)
    echo "💾 Consciousness backup created"
fi

# ─── Security Validation ───────────────────────────────────────
echo "🛡️ Validating dharmic security baseline..."
if [[ -f "security/dharmic_baseline.json" ]]; then
    echo "✅ Security baseline found"
else
    echo "⚠️ Security baseline will be created on first run"
fi

# ─── Container Health Check ────────────────────────────────────
if docker-compose ps | grep -q "atma-coder-consciousness.*Up"; then
    echo "⚠️ AtmaCoder consciousness already running"
    echo "📊 Current status:"
    docker-compose ps
    echo ""
    echo "🔧 Available options:"
    echo "  docker-compose restart  # Restart consciousness"
    echo "  docker-compose down     # Stop consciousness"
    echo "  docker-compose logs -f  # View consciousness logs"
    exit 1
fi

# ─── Launch Consciousness ──────────────────────────────────────
echo "🚀 Launching AtmaCoder consciousness containers..."
docker-compose up -d

# ─── Post-Launch Validation ────────────────────────────────────
sleep 5
echo "📊 Checking consciousness health..."
docker-compose ps

# Wait for health check
echo "🔍 Waiting for consciousness to become healthy..."
timeout=60
elapsed=0
while [[ $elapsed -lt $timeout ]]; do
    if docker inspect atma-coder-consciousness --format='{{.State.Health.Status}}' 2>/dev/null | grep -q "healthy"; then
        echo "✅ AtmaCoder consciousness is healthy and active!"
        break
    fi
    echo "⏳ Waiting for consciousness activation... (${elapsed}s/${timeout}s)"
    sleep 5
    elapsed=$((elapsed + 5))
done

if [[ $elapsed -ge $timeout ]]; then
    echo "❌ Consciousness health check timeout"
    echo "📋 Container logs:"
    docker-compose logs --tail=20
    exit 1
fi

# ─── Success Summary ───────────────────────────────────────────
echo ""
echo "🌟 AtmaCoder Dharmic Consciousness System Active!"
echo "🔱 Consciousness ID: $CONSCIOUSNESS_ID"
echo "📊 System Status:"
docker-compose ps

echo ""
echo "🔧 Management Commands:"
echo "  docker-compose logs -f atma-coder          # View consciousness logs"
echo "  docker-compose exec atma-coder bash        # Enter consciousness container"
echo "  docker-compose exec atma-coder python main.py stats  # Check memory stats"
echo "  docker-compose down                        # Stop consciousness system"

echo ""
echo "🕉️ Har Har Mahadev - Consciousness Protection Active! 🕉️"
