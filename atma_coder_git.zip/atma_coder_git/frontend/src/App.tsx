import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'
import AdvancedDashboard from './pages/AdvancedDashboard'
import Consciousness from './pages/Consciousness'
import Dharma from './pages/Dharma'
import Logs from './pages/Logs'
import System from './pages/System'

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/dashboard" element={<Layout><System /></Layout>} />
      <Route path="/dashboard/advanced" element={<Layout><AdvancedDashboard /></Layout>} />
      <Route path="/dashboard/consciousness" element={<Layout><Consciousness /></Layout>} />
      <Route path="/dashboard/dharma" element={<Layout><Dharma /></Layout>} />
      <Route path="/dashboard/logs" element={<Layout><Logs /></Layout>} />
    </Routes>
  )
}

export default App
