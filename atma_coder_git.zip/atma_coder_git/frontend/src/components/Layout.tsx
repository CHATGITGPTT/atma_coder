import React from 'react'
import Sidebar from './Sidebar'
import Header from './Header'
import StatusBar from './StatusBar'

interface LayoutProps {
  children: React.ReactNode
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-black">
      <div className="flex">
        {/* Sidebar */}
        <Sidebar />
        
        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <Header />
          
          {/* Main Content Area */}
          <main className="flex-1 p-6 overflow-auto">
            {children}
          </main>
          
          {/* Status Bar */}
          <StatusBar />
        </div>
      </div>
    </div>
  )
}

export default Layout
