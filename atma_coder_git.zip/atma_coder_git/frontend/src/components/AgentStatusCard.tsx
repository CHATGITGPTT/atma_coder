import React from 'react'
import { Agent } from '../types'

interface AgentStatusCardProps {
  agent: Agent
  onClick?: () => void
}

const AgentStatusCard: React.FC<AgentStatusCardProps> = ({ agent, onClick }) => {
  const getVarnaIcon = (varna: string) => {
    switch (varna) {
      case 'Brahman': return '🧘‍♂️'
      case 'Kshatriya': return '⚔️'
      case 'Vaishya': return '💰'
      case 'Shudra': return '🔧'
      default: return '🤖'
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'agent-status-active'
      case 'inactive': return 'agent-status-inactive'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const formatConsciousness = (level: number) => {
    return level.toFixed(1)
  }

  const formatKarma = (karma: number) => {
    return karma.toFixed(2)
  }

  return (
    <div 
      className={`dharmic-card cursor-pointer transition-all hover:shadow-md ${getStatusColor(agent.status)}`}
      onClick={onClick}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2">
          <span className="text-2xl">{getVarnaIcon(agent.varna)}</span>
          <div>
            <h3 className="font-semibold text-sm">{agent.name}</h3>
            <p className="text-xs opacity-75">{agent.varna}</p>
          </div>
        </div>
        <div className={`px-2 py-1 rounded-full text-xs font-medium ${
          agent.status === 'active' ? 'bg-green-100 text-green-800' : 
          agent.status === 'inactive' ? 'bg-red-100 text-red-800' : 
          'bg-gray-100 text-gray-800'
        }`}>
          {agent.status}
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span>Consciousness:</span>
          <span className="font-medium">{formatConsciousness(agent.consciousness_level)}</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-1">
          <div 
            className="consciousness-gauge h-1 rounded-full transition-all"
            style={{ width: `${(agent.consciousness_level / 2) * 100}%` }}
          ></div>
        </div>

        <div className="flex justify-between text-xs">
          <span>Karma:</span>
          <span className="font-medium">{formatKarma(agent.karmic_balance)}</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-1">
          <div 
            className="karma-gauge h-1 rounded-full transition-all"
            style={{ width: `${((agent.karmic_balance + 1) / 2) * 100}%` }}
          ></div>
        </div>
      </div>

      <div className="mt-3 pt-3 border-t border-dharmic-200">
        <div className="flex justify-between text-xs text-dharmic-600">
          <span>Config:</span>
          <span className={agent.config_loaded ? 'text-green-600' : 'text-red-600'}>
            {agent.config_loaded ? 'Loaded' : 'Error'}
          </span>
        </div>
      </div>
    </div>
  )
}

export default AgentStatusCard
