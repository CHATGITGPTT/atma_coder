import React from 'react'

interface TrishulIconProps {
  size?: number
  className?: string
}

const TrishulIcon: React.FC<TrishulIconProps> = ({ size = 64, className = '' }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`trishul-icon ${className}`}
    >
      {/* Main Staff */}
      <path
        d="M32 8 L32 56"
        stroke="url(#flameGradient)"
        strokeWidth="3"
        strokeLinecap="round"
      />
      
      {/* Left Prong */}
      <path
        d="M20 16 L28 24 L20 32"
        stroke="url(#flameGradient)"
        strokeWidth="2"
        strokeLinecap="round"
      />
      
      {/* Right Prong */}
      <path
        d="M44 16 L36 24 L44 32"
        stroke="url(#flameGradient)"
        strokeWidth="2"
        strokeLinecap="round"
      />
      
      {/* Center Prong */}
      <path
        d="M32 16 L32 32"
        stroke="url(#flameGradient)"
        strokeWidth="2"
        strokeLinecap="round"
      />
      
      {/* Energy Orbs */}
      <circle cx="32" cy="12" r="2" fill="url(#energyGradient)" />
      <circle cx="24" cy="20" r="1.5" fill="url(#energyGradient)" />
      <circle cx="40" cy="20" r="1.5" fill="url(#energyGradient)" />
      <circle cx="32" cy="28" r="1.5" fill="url(#energyGradient)" />
      
      {/* Gradients */}
      <defs>
        <linearGradient id="flameGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ff4500" />
          <stop offset="50%" stopColor="#ff8c00" />
          <stop offset="100%" stopColor="#ff4500" />
        </linearGradient>
        <radialGradient id="energyGradient" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#ff4500" />
          <stop offset="100%" stopColor="#ff8c00" />
        </radialGradient>
      </defs>
    </svg>
  )
}

export default TrishulIcon 