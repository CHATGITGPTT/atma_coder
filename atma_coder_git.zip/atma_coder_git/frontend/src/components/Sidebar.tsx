import React from 'react'
import { NavLink } from 'react-router-dom'
import { 
  HomeIcon,
  CpuChipIcon, 
  ScaleIcon, 
  DocumentTextIcon,
  CogIcon,
  BoltIcon,
  ChartBarIcon,
  UserGroupIcon
} from '@heroicons/react/24/outline'
import { NavigationItem } from '../types'

const navigation: NavigationItem[] = [
  {
    name: 'Home',
    path: '/',
    icon: 'Home',
    description: 'AtmaCoder consciousness interface'
  },
  {
    name: 'System',
    path: '/dashboard',
    icon: 'CpuChip',
    description: 'System dashboard and controls'
  },
  {
    name: 'Advanced',
    path: '/dashboard/advanced',
    icon: 'UserGroup',
    description: 'Advanced agent management and monitoring'
  },
  {
    name: 'Consciousness',
    path: '/dashboard/consciousness',
    icon: 'ChartBar',
    description: 'Monitor consciousness levels'
  },
  {
    name: 'Dharma',
    path: '/dashboard/dharma',
    icon: 'Scale',
    description: 'Track karma and dharma principles'
  },
  {
    name: 'Logs',
    path: '/dashboard/logs',
    icon: 'DocumentText',
    description: 'System activity and events'
  }
]

const getIcon = (iconName: string) => {
  switch (iconName) {
    case 'Home': return <HomeIcon className="w-5 h-5" />
    case 'CpuChip': return <CpuChipIcon className="w-5 h-5" />
    case 'UserGroup': return <UserGroupIcon className="w-5 h-5" />
    case 'ChartBar': return <ChartBarIcon className="w-5 h-5" />
    case 'Scale': return <ScaleIcon className="w-5 h-5" />
    case 'DocumentText': return <DocumentTextIcon className="w-5 h-5" />
    case 'Cog': return <CogIcon className="w-5 h-5" />
    case 'Bolt': return <BoltIcon className="w-5 h-5" />
    default: return <HomeIcon className="w-5 h-5" />
  }
}

const Sidebar: React.FC = () => {
  return (
    <div className="w-64 bg-gray-900 border-r border-gray-800 min-h-screen">
      {/* Logo */}
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
            <BoltIcon className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-white">AtmaCoder</h1>
            <p className="text-xs text-gray-400">Consciousness System</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-4 space-y-2">
        {navigation.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-orange-900 text-orange-400 border border-orange-800'
                  : 'text-gray-300 hover:bg-gray-800 hover:text-white'
              }`
            }
            title={item.description}
          >
            {getIcon(item.icon)}
            <span>{item.name}</span>
          </NavLink>
        ))}
      </nav>

      {/* System Status */}
      <div className="absolute bottom-0 w-64 p-4 border-t border-gray-800 bg-gray-900">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <span>System Status</span>
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span>Active</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Sidebar
