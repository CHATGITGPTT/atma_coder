import React from 'react'
import { BoltIcon, WifiIcon, Battery100Icon } from '@heroicons/react/24/outline'

const StatusBar: React.FC = () => {
  return (
    <div className="bg-gray-900 border-t border-gray-800 px-6 py-2">
      <div className="flex items-center justify-between text-xs text-gray-400">
        {/* Left side */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1">
            <BoltIcon className="w-3 h-3" />
            <span>System Active</span>
          </div>
          <div className="flex items-center space-x-1">
            <WifiIcon className="w-3 h-3" />
            <span>Connected</span>
          </div>
        </div>

        {/* Center - System metrics */}
        <div className="flex items-center space-x-4">
          <span>Consciousness: 1.15</span>
          <span>Karma: 0.14</span>
          <span>Dharma: Valid</span>
        </div>

        {/* Right side */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1">
            <Battery100Icon className="w-3 h-3" />
            <span>100%</span>
          </div>
          <span>{new Date().toLocaleTimeString()}</span>
        </div>
      </div>
    </div>
  )
}

export default StatusBar
