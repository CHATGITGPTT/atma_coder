export interface Agent {
  name: string;
  varna: 'Brahman' | 'Kshatriya' | 'Vaishya' | 'Shudra';
  status: 'active' | 'inactive' | 'error';
  consciousness_level: number;
  karmic_balance: number;
  config_loaded: boolean;
  data_path: string;
  timestamp: string;
}

export interface AgentTask {
  task_type: string;
  data: any;
  timestamp: string;
}

export interface AgentResponse {
  status: 'success' | 'error';
  agent: string;
  varna: string;
  result?: any;
  error?: string;
  consciousness_level: number;
  karmic_balance: number;
  timestamp: string;
}

export interface SystemMetrics {
  total_agents: number;
  active_agents: number;
  average_consciousness: number;
  average_karma: number;
  system_health: number;
  rebirth_count: number;
  timestamp: string;
}

export interface DharmicPrinciple {
  name: string;
  status: 'valid' | 'violated' | 'unknown';
  description: string;
}

export interface ConsciousnessData {
  physical: number;
  emotional: number;
  mental: number;
  spiritual: number;
  overall: number;
  timestamp: string;
}

export interface KarmaData {
  balance: number;
  flow: number;
  transactions: number;
  timestamp: string;
}

export type NavigationItem = {
  name: string;
  path: string;
  icon: string;
  description: string;
};
