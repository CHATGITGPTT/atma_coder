# AtmaCoder Frontend

A React-based dashboard for the AtmaCoder Dharmic AI System.

## Features

- **Dashboard Home** - System overview with agent status grid
- **Agent Management** - Individual agent control and task sending
- **Consciousness Center** - Monitor consciousness levels across domains
- **Karma & Dharma** - Track karma balance and dharma principles

## Tech Stack

- **React 18** - UI framework
- **TypeScript** - Type safety
- **Tailwind CSS** - Styling
- **Lucide React** - Icons
- **React Router** - Navigation
- **Vite** - Build tool

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start development server:
   ```bash
   npm run dev
   ```

3. Build for production:
   ```bash
   npm run build
   ```

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── Layout.tsx      # Main layout with sidebar, header, status bar
│   ├── Sidebar.tsx     # Navigation sidebar
│   ├── Header.tsx      # Top header
│   ├── StatusBar.tsx   # Bottom status bar
│   └── AgentStatusCard.tsx # Agent status display
├── pages/              # Page components
│   ├── Dashboard.tsx   # Main dashboard
│   ├── AgentManagement.tsx # Agent management
│   ├── ConsciousnessCenter.tsx # Consciousness monitoring
│   └── KarmaDharma.tsx # Karma and dharma tracking
├── types/              # TypeScript type definitions
├── styles/             # CSS styles
└── utils/              # Utility functions
```

## Design Philosophy

The frontend follows dharmic principles:
- **Satya (Truth)** - Honest and transparent UI
- **Ahimsa (Non-violence)** - Harmless and beneficial design
- **Tapasya (Discipline)** - Focused and dedicated functionality
- **Karma (Action)** - Righteous and purposeful interactions

## Color Palette

- **Dharmic** - Neutral grays for structure
- **Consciousness** - Blues for awareness
- **Karma** - Yellows for balance
- **Status** - Greens for success, reds for errors

## Development

The frontend is designed to be:
- **Minimalist** - Clean, uncluttered interface
- **Karma-aware** - Visual feedback for dharmic alignment
- **Real-time** - Live updates from the backend
- **Accessible** - Usable by all users

## API Integration

The frontend connects to the AtmaCoder backend API for:
- Agent status and control
- Consciousness monitoring
- Karma tracking
- Dharma validation
- System metrics

## License

MIT License - See LICENSE file for details.
