import asyncio
import json
import os
import threading
import time
from datetime import datetime

import psutil
import requests
from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

from automation.workflow_engine import WorkflowEngine
from config.runtime_config import get_model, set_model
from config.settings import AppSettings
from core.event_bus import EventBus
from core.model_router import route_model
from core.orchestrator import Orchestrator
from core.personality_core import PersonalityCore
from core.rebirth_protocol import RebirthProtocol
from memory.graph_backends import sqlite_graph_client

load_dotenv()

app = Flask(__name__)
CORS(app)

# Core setup
settings = AppSettings()
graph_client = sqlite_graph_client.SQLiteGraphClient(os.getenv("SQLITE_DB_PATH"))
event_bus = EventBus()
orchestrator = Orchestrator(settings=settings, event_bus=event_bus)
workflow_engine = WorkflowEngine(event_bus=event_bus, ethical_engine=orchestrator.ethical_engine)
personality_core = PersonalityCore()

# Initialize Rebirth Protocol
rebirth_protocol = RebirthProtocol(
    graph_client=graph_client,
    dharma_enforcer=orchestrator.dharma,
    agent_registry=orchestrator.agent_registry if hasattr(orchestrator, 'agent_registry') else None,
    event_bus=event_bus
)

# Global state tracking
current_persona = "BRAHMAN"
system_metrics = {
    "server_start_time": time.time(),
    "request_count": 0,
    "last_request_time": None,
    "active_connections": 0,
    "error_count": 0,
    "model_switch_count": 0,
    "memory_operations": 0,
    "rebirth_count": 0,
}

# Dynamic API configuration storage
api_configs = {}

# Real-time monitoring data
live_metrics = {
    "cpu_usage": 0,
    "memory_usage": 0,
    "disk_usage": 0,
    "network_io": {"bytes_sent": 0, "bytes_recv": 0},
    "active_models": [],
    "response_times": [],
    "error_rate": 0,
}


def update_system_metrics():
    """Update system metrics in real-time"""
    global live_metrics
    while True:
        try:
            # CPU and Memory usage
            live_metrics["cpu_usage"] = psutil.cpu_percent(interval=1)
            live_metrics["memory_usage"] = psutil.virtual_memory().percent
            live_metrics["disk_usage"] = psutil.disk_usage("/").percent

            # Network IO
            net_io = psutil.net_io_counters()
            live_metrics["network_io"] = {"bytes_sent": net_io.bytes_sent, "bytes_recv": net_io.bytes_recv}

            # Calculate error rate
            if system_metrics["request_count"] > 0:
                live_metrics["error_rate"] = (system_metrics["error_count"] / system_metrics["request_count"]) * 100

            time.sleep(5)  # Update every 5 seconds
        except Exception as e:
            print(f"[METRICS] Error updating metrics: {e}")
            time.sleep(10)


# Start metrics monitoring thread
metrics_thread = threading.Thread(target=update_system_metrics, daemon=True)
metrics_thread.start()


def log_request(endpoint, success=True, response_time=None):
    """Log request for monitoring"""
    global system_metrics
    system_metrics["request_count"] += 1
    system_metrics["last_request_time"] = time.time()

    if not success:
        system_metrics["error_count"] += 1


def is_rebirth_command(prompt: str) -> bool:
    """
    Detect if the prompt is a rebirth command.
    """
    rebirth_indicators = [
        "invoke root command: connect all memory, dharma, and varna for system rebirth",
        "system rebirth",
        "rebirth protocol",
        "connect all memory dharma varna",
        "system reset",
        "consciousness reset"
    ]
    
    prompt_lower = prompt.lower()
    return any(indicator in prompt_lower for indicator in rebirth_indicators)


async def execute_rebirth_async():
    """
    Execute rebirth protocol asynchronously.
    """
    try:
        rebirth_result = await rebirth_protocol.execute_rebirth(protection_level="varna")
        system_metrics["rebirth_count"] += 1
        return rebirth_result
    except Exception as e:
        print(f"[REBIRTH] Error executing rebirth: {e}")
        return {
            "status": "failed",
            "message": f"Rebirth execution failed: {str(e)}",
            "timestamp": datetime.now().isoformat()
        }


def execute_rebirth_sync():
    """
    Execute rebirth protocol synchronously using asyncio.
    """
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(execute_rebirth_async())
        loop.close()
        return result
    except Exception as e:
        print(f"[REBIRTH] Error in sync rebirth execution: {e}")
        return {
            "status": "failed",
            "message": f"Rebirth execution failed: {str(e)}",
            "timestamp": datetime.now().isoformat()
        }


def load_available_models():
    """Dynamically load available models from environment variables"""
    models = []

    # Check for OpenAI
    if os.getenv("OPENAI_API_KEY"):
        models.extend(["gpt-4", "gpt-3.5-turbo", "gpt-4-turbo"])
        api_configs["openai"] = {"api_key": os.getenv("OPENAI_API_KEY"), "base_url": "https://api.openai.com/v1"}

    # Check for Gemini
    gemini_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GOOGLE_GEMINI_API_KEY") or os.getenv("GEMINI_API_KEY")
    if gemini_key:
        models.extend(["gemini-1.0-pro", "gemini-1.5-flash", "gemini-1.5-pro"])
        api_configs["gemini"] = {"api_key": gemini_key, "base_url": "https://generativelanguage.googleapis.com/v1beta"}

    # Check for Claude/Anthropic
    if os.getenv("ANTHROPIC_API_KEY"):
        models.extend(["claude-3-sonnet", "claude-3-haiku", "claude-3-opus"])
        api_configs["anthropic"] = {"api_key": os.getenv("ANTHROPIC_API_KEY"), "base_url": "https://api.anthropic.com"}

    # Check for Ollama (local)
    if os.getenv("OLLAMA_URL") or check_ollama_running():
        ollama_models = get_ollama_models()
        models.extend(ollama_models)
        api_configs["ollama"] = {"base_url": os.getenv("OLLAMA_URL", "http://localhost:11434")}

    # Always have a fallback
    if not models:
        models.append("fallback")

    live_metrics["active_models"] = models
    print(f"[MODELS] Loaded models: {models}")

    return models


def check_ollama_running():
    """Check if Ollama is running locally"""
    try:
        response = requests.get("http://localhost:11434/api/tags", timeout=2)
        return response.status_code == 200
    except BaseException:
        return False


def get_ollama_models():
    """Get available models from Ollama"""
    try:
        response = requests.get("http://localhost:11434/api/tags", timeout=5)
        if response.status_code == 200:
            data = response.json()
            return [model["name"].split(":")[0] for model in data.get("models", [])]
    except Exception as e:
        print(f"[OLLAMA] Error getting models: {e}")
    return ["deepseek-coder", "llama2"]


def test_model_connectivity(model_name):
    """Test if a model is actually accessible"""
    try:
        start_time = time.time()
        test_prompt = "Hello"
        response = make_api_call(model_name, test_prompt)
        response_time = time.time() - start_time

        if "error" in response.lower() or "failed" in response.lower():
            return False, response_time
        return True, response_time
    except Exception as e:
        return False, 0


def make_api_call(model_name, prompt):
    """Make actual API calls to different providers"""
    try:
        start_time = time.time()
        print(f"[API_CALL] Using {model_name}: {prompt[:50]}...")

        # OpenAI models
        if model_name in ["gpt-4", "gpt-3.5-turbo", "gpt-4-turbo"] and "openai" in api_configs:
            result = call_openai_api(model_name, prompt)
        # Gemini models
        elif model_name in ["gemini-1.0-pro", "gemini-1.5-flash", "gemini-1.5-pro"] and "gemini" in api_configs:
            result = call_gemini_api(model_name, prompt)
        # Claude models
        elif model_name in ["claude-3-sonnet", "claude-3-haiku", "claude-3-opus"] and "anthropic" in api_configs:
            result = call_anthropic_api(model_name, prompt)
        # Ollama models
        elif "ollama" in api_configs:
            result = call_ollama_api(model_name, prompt)
        else:
            result = f"Model {model_name} not configured"

        response_time = time.time() - start_time
        log_request("/api_call", True, response_time)
        return result

    except Exception as e:
        log_request("/api_call", False)
        return f"API call failed: {str(e)}"


def call_openai_api(model_name, prompt):
    """Call OpenAI API"""
    try:
        headers = {"Authorization": f"Bearer {api_configs['openai']['api_key']}", "Content-Type": "application/json"}

        data = {"model": model_name, "messages": [{"role": "user", "content": prompt}], "max_tokens": 1000}

        response = requests.post(
            f"{api_configs['openai']['base_url']}/chat/completions", headers=headers, json=data, timeout=30
        )

        if response.status_code == 200:
            result = response.json()
            return result["choices"][0]["message"]["content"]
        else:
            return f"OpenAI API error: {response.text}"
    except Exception as e:
        return f"OpenAI call failed: {str(e)}"


def call_gemini_api(model_name, prompt):
    """Call Gemini API with correct model mapping"""
    try:
        model_mapping = {
            "gemini-1.0-pro": "gemini-pro",
            "gemini-1.5-flash": "gemini-1.5-flash-latest",
            "gemini-1.5-pro": "gemini-1.5-pro-latest",
        }

        api_model_name = model_mapping.get(model_name, "gemini-pro")
        url = f"{api_configs['gemini']['base_url']}/models/{api_model_name}:generateContent"

        data = {"contents": [{"parts": [{"text": prompt}]}]}

        params = {"key": api_configs["gemini"]["api_key"]}
        response = requests.post(url, json=data, params=params, timeout=30)

        if response.status_code == 200:
            result = response.json()
            if "candidates" in result and len(result["candidates"]) > 0:
                return result["candidates"][0]["content"]["parts"][0]["text"]
        return f"Gemini API error: {response.text}"
    except Exception as e:
        return f"Gemini call failed: {str(e)}"


def call_anthropic_api(model_name, prompt):
    """Call Anthropic Claude API"""
    try:
        headers = {
            "x-api-key": api_configs["anthropic"]["api_key"],
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01",
        }

        data = {"model": model_name, "max_tokens": 1000, "messages": [{"role": "user", "content": prompt}]}

        response = requests.post(
            f"{api_configs['anthropic']['base_url']}/v1/messages", headers=headers, json=data, timeout=30
        )

        if response.status_code == 200:
            result = response.json()
            return result["content"][0]["text"]
        return f"Claude API error: {response.text}"
    except Exception as e:
        return f"Claude call failed: {str(e)}"


def call_ollama_api(model_name, prompt):
    """Call local Ollama API"""
    try:
        url = f"{api_configs['ollama']['base_url']}/api/generate"
        data = {"model": model_name, "prompt": prompt, "stream": False}
        response = requests.post(url, json=data, timeout=60)

        if response.status_code == 200:
            result = response.json()
            return result.get("response", "No response from Ollama")
        return f"Ollama API error: {response.text}"
    except Exception as e:
        return f"Ollama call failed: {str(e)}"


# Initialize available models
AVAILABLE_MODELS = load_available_models()


@app.route("/status", methods=["GET"])
def get_status():
    """Enhanced status with real-time monitoring"""
    global current_persona
    try:
        start_time = time.time()
        current_model = get_model()

        # Reload models dynamically
        global AVAILABLE_MODELS
        AVAILABLE_MODELS = load_available_models()

        # Enhanced health checks
        try:
            varna_status = "ready" if orchestrator else "error"
        except BaseException:
            varna_status = "error"

        try:
            memory_status = "ready" if graph_client else "error"
        except BaseException:
            memory_status = "error"

        # Test current model
        try:
            if current_model and current_model in AVAILABLE_MODELS:
                model_works, response_time = test_model_connectivity(current_model)
                llm_status = "ready" if model_works else "error"
            else:
                llm_status = "error"
        except BaseException:
            llm_status = "error"

        status = {
            "persona": current_persona,
            "llm": {
                "model_name": current_model or (AVAILABLE_MODELS[0] if AVAILABLE_MODELS else "No model"),
                "status": llm_status,
            },
            "memory": {"status": memory_status},
            "varna_core": {"status": varna_status},
            "available_models": AVAILABLE_MODELS,
            "api_configs": list(api_configs.keys()),
            "system_metrics": system_metrics,
            "live_metrics": live_metrics,
        }

        response_time = time.time() - start_time
        log_request("/status", True, response_time)
        return jsonify(status)

    except Exception as e:
        log_request("/status", False)
        return jsonify({"error": str(e)}), 500


@app.route("/respond", methods=["POST"])
def get_response():
    """Enhanced response with monitoring and rebirth protocol integration"""
    try:
        start_time = time.time()
        data = request.get_json()
        prompt = data.get("prompt", "")

        if not prompt:
            return jsonify({"error": "No prompt provided"}), 400

        current_model = get_model()
        print(f"[RESPOND] Using {current_model}: {prompt}")

        # Check for rebirth command first
        if is_rebirth_command(prompt):
            print("[RESPOND] 🌀 Detected rebirth command. Executing rebirth protocol.")
            rebirth_result = execute_rebirth_sync()
            
            # Update system metrics for rebirth
            if rebirth_result.get("status") == "success":
                system_metrics["rebirth_count"] += 1
            
            # Format rebirth response
            if rebirth_result.get("status") == "success":
                response_message = f"🌀 REBIRTH PROTOCOL COMPLETED SUCCESSFULLY\n\nRebirth ID: {rebirth_result.get('rebirth_id')}\nDuration: {rebirth_result.get('duration_seconds', 0):.2f}s\n\nMetrics:\n- Memory Cleanup: {rebirth_result.get('metrics', {}).get('memory_cleanup', {}).get('status', 'unknown')}\n- Dharma Reset: {rebirth_result.get('metrics', {}).get('dharma_reset', {}).get('status', 'unknown')}\n- Agent Sync: {rebirth_result.get('metrics', {}).get('agent_sync', {}).get('status', 'unknown')}\n- Consciousness Optimization: {rebirth_result.get('metrics', {}).get('consciousness_opt', {}).get('status', 'unknown')}\n\nSystem has been reborn with renewed consciousness and optimized memory."
            else:
                response_message = f"❌ REBIRTH PROTOCOL FAILED\n\nError: {rebirth_result.get('message', 'Unknown error')}\n\nPlease check system logs for details."
            
            response_time = time.time() - start_time
            log_request("/respond", rebirth_result.get("status") == "success", response_time)
            return jsonify({"response": response_message})

        # Normal response processing with enhanced fallback
        try:
            response = make_api_call(current_model, prompt)

            # Check for errors
            if any(keyword in response.lower() for keyword in ["error", "failed", "unknown model"]):
                raise Exception("API call returned error")

            response_time = time.time() - start_time
            log_request("/respond", True, response_time)
            return jsonify({"response": response})

        except Exception as api_error:
            print(f"[RESPOND] API failed: {api_error}")
            try:
                # Use enhanced model router with fallback
                response = route_model(prompt)
                if response and not any(keyword in response.lower() for keyword in ["error", "failed", "unknown model"]):
                    response_time = time.time() - start_time
                    log_request("/respond", True, response_time)
                    return jsonify({"response": response})
                else:
                    raise Exception("Router failed")
            except BaseException as router_error:
                print(f"[RESPOND] Router failed: {router_error}")
                # Final fallback to personality core
                fallback = personality_core.respond_with_success(prompt)
                response_time = time.time() - start_time
                log_request("/respond", True, response_time)
                return jsonify({"response": f"[System Fallback] {fallback}"})

    except Exception as e:
        log_request("/respond", False)
        return jsonify({"error": str(e)}), 500


@app.route("/model", methods=["POST"])
def switch_model():
    """Enhanced model switching with monitoring"""
    try:
        data = request.get_json()
        new_model = data.get("model_name", "")

        if not new_model or new_model not in AVAILABLE_MODELS:
            return jsonify({"error": f"Invalid model. Available: {AVAILABLE_MODELS}"}), 400

        set_model(new_model)
        system_metrics["model_switch_count"] += 1

        # Test new model
        model_works, response_time = test_model_connectivity(new_model)

        return jsonify(
            {
                "status": "model updated successfully",
                "current_model": get_model(),
                "model_accessible": model_works,
                "test_response_time": response_time,
            }
        )

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/persona/load", methods=["POST"])
def load_persona():
    """Enhanced persona loading"""
    global current_persona
    try:
        data = request.get_json()
        persona_name = data.get("persona_name", "")

        if not persona_name:
            return jsonify({"error": "No persona name provided"}), 400

        old_persona = current_persona
        current_persona = persona_name.upper()

        # Try to update personality core
        try:
            if hasattr(personality_core, "set_persona"):
                personality_core.set_persona(persona_name)
        except Exception as e:
            print(f"[PERSONA] Core update failed: {e}")

        return jsonify(
            {
                "status": f"persona '{persona_name}' loaded successfully",
                "persona": current_persona,
                "previous_persona": old_persona,
            }
        )

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/memory/fact", methods=["POST"])
def inject_fact():
    try:
        data = request.get_json()
        fact = data.get("fact", "")

        if not fact.strip():
            return jsonify({"error": "No valid fact provided"}), 400

        graph_client.store_fact(fact)
        system_metrics["memory_operations"] += 1

        return jsonify({"status": "fact stored successfully", "fact": fact})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/memory/reset", methods=["POST"])
def reset_memory():
    try:
        if hasattr(graph_client, "reset_memory"):
            graph_client.reset_memory()
        system_metrics["memory_operations"] += 1
        return jsonify({"status": "memory reset successful"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/session/save", methods=["POST"])
def save_session():
    try:
        session_data = {
            "persona": current_persona,
            "model": get_model(),
            "timestamp": datetime.now().isoformat(),
            "metrics": system_metrics,
        }
        return jsonify({"status": "session saved successfully", "data": session_data})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/system/health", methods=["GET"])
def get_system_health():
    """Real-time system health monitoring"""
    try:
        uptime = time.time() - system_metrics["server_start_time"]

        health_data = {
            "server": {
                "status": "running",
                "uptime_seconds": uptime,
                "uptime_formatted": f"{int(uptime//3600)}h {int((uptime%3600)//60)}m",
                "url": "http://localhost:8000",
                "port": 8000,
            },
            "system": {
                "cpu_usage": live_metrics["cpu_usage"],
                "memory_usage": live_metrics["memory_usage"],
                "disk_usage": live_metrics["disk_usage"],
                "load_average": os.getloadavg() if hasattr(os, "getloadavg") else [0, 0, 0],
            },
            "api": {
                "total_requests": system_metrics["request_count"],
                "error_count": system_metrics["error_count"],
                "error_rate": live_metrics["error_rate"],
                "avg_response_time": (
                    sum(live_metrics["response_times"][-10:]) / len(live_metrics["response_times"][-10:])
                    if live_metrics["response_times"]
                    else 0
                ),
                "last_request": system_metrics["last_request_time"],
            },
            "models": {
                "active_models": live_metrics["active_models"],
                "current_model": get_model(),
                "model_switches": system_metrics["model_switch_count"],
            },
            "memory": {
                "operations": system_metrics["memory_operations"],
                "graph_status": "ready" if graph_client else "error",
            },
            "network": live_metrics["network_io"],
        }

        return jsonify(health_data)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/list", methods=["GET"])
def list_api_configs():
    """List current API configurations"""
    try:
        configs = {}
        for provider, config in api_configs.items():
            configs[provider] = {
                "base_url": config.get("base_url", ""),
                "has_api_key": bool(config.get("api_key", "")),
                "api_key_preview": config.get("api_key", "")[:10] + "..." if config.get("api_key", "") else "",
            }

        return jsonify({"api_configs": configs, "available_models": AVAILABLE_MODELS})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/memory/graph", methods=["GET"])
def export_memory_graph():
    """Export memory graph data"""
    try:
        graph_data = graph_client.export_graph()
        return jsonify(graph_data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/rebirth/status", methods=["GET"])
def get_rebirth_status():
    """Get rebirth protocol status and statistics"""
    try:
        rebirth_stats = rebirth_protocol.get_rebirth_stats()
        return jsonify({
            "rebirth_protocol": {
                "status": "active",
                "version": "1.0",
                "varna": "BRAHMAN"
            },
            "statistics": rebirth_stats,
            "system_metrics": {
                "total_rebirths": system_metrics.get("rebirth_count", 0),
                "last_rebirth": rebirth_stats.get("last_rebirth")
            }
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    print("🚀 Starting AtmaCoder API Server...")
    print(f"📊 Available models: {load_available_models()}")
    print(f"🔧 Current model: {get_model()}")
    print(f"🌐 Server will run on: http://localhost:8000")
    print(f"🌀 Rebirth Protocol: ACTIVE (BRAHMAN varna)")
    print("=" * 50)
    app.run(host="0.0.0.0", port=8000, debug=True)
