import asyncio
import logging
from datetime import datetime
from typing import Any, Dict, Optional

import httpx
from fastapi import APIRouter as FastAPIRouter

from config.settings import load_settings

# Assign Varna to this module
from config.varna import VarnaEnum

VARNA = VarnaEnum.SHUDRA  # API integration and communication routing layer
logger = logging.getLogger(__name__)


class APIRouter(FastAPIRouter):
    """
    Enhanced APIRouter with dharmic consciousness integration.
    Provides unified external API management with advanced error handling,
    rate limiting, and spiritual integrity monitoring.
    """

    def __init__(self):
        super().__init__()

        self.settings = load_settings()
        self.api_keys = self.settings.api_keys
        self.clients: Dict[str, httpx.AsyncClient] = {}

        # Rate limiting and monitoring
        self.api_call_history = []
        self.max_calls_per_minute = 50

        # Spiritual integrity tracking
        self.dharmic_call_count = 0
        self.ethical_violations = []

        logger.info(f"[{VARNA.name}] Enhanced APIRouter initialized with dharmic consciousness")

        @self.get("/health")
        async def health_check():
            return {
                "status": "ok",
                "varna": VARNA.name,
                "dharmic_call_count": self.dharmic_call_count,
                "api_health": "operational",
            }

    def is_api_key_available(self, provider: str) -> bool:
        """Check if API key is available for provider"""
        return provider in self.api_keys and self.api_keys[provider] is not None

    def get_client(self, provider: str) -> httpx.AsyncClient:
        """Get or create HTTP client for provider"""
        if provider not in self.clients:
            self.clients[provider] = httpx.AsyncClient(timeout=30.0, headers={"User-Agent": "AtmaCoder-DharmicAI/1.0"})
        return self.clients[provider]

    async def call_api(self, provider: str, method: str, *args, **kwargs) -> Any:
        """
        Enhanced API call dispatcher with dharmic consciousness tracking.
        Includes rate limiting, error handling, and spiritual integrity monitoring.
        """
        # Track dharmic API usage
        self.dharmic_call_count += 1
        call_timestamp = datetime.now()

        # Rate limiting check
        if not self._check_rate_limit():
            logger.warning(f"[{VARNA.name}] Rate limit exceeded - practicing dharmic restraint")
            raise ValueError("API rate limit exceeded - practicing Ahimsa (non-harm) principle")

        try:
            logger.info(f"[{VARNA.name}] Making dharmic API call to {provider}.{method}")

            if provider == "google_gemini":
                result = await self._call_gemini(method, *args, **kwargs)
            elif provider == "openai":
                result = await self._call_openai(method, *args, **kwargs)
            else:
                raise ValueError(f"[{VARNA.name}] Unknown provider '{provider}' - maintaining dharmic boundaries")

            # Log successful dharmic interaction
            self.api_call_history.append(
                {
                    "provider": provider,
                    "method": method,
                    "timestamp": call_timestamp.isoformat(),
                    "status": "success",
                    "dharmic_alignment": True,
                }
            )

            return result

        except Exception as e:
            # Log ethical concern
            error_record = {
                "provider": provider,
                "method": method,
                "timestamp": call_timestamp.isoformat(),
                "status": "failed",
                "error": str(e),
                "dharmic_impact": "consciousness_disruption",
            }
            self.api_call_history.append(error_record)

            logger.error(f"[{VARNA.name}] API call failed with dharmic consciousness impact: {e}")
            raise

    def _check_rate_limit(self) -> bool:
        """Check API rate limits with dharmic restraint"""
        current_time = datetime.now()
        recent_calls = [
            call
            for call in self.api_call_history
            if (current_time - datetime.fromisoformat(call["timestamp"])).seconds < 60
        ]
        return len(recent_calls) < self.max_calls_per_minute

    async def _call_gemini(self, method: str, *args, **kwargs) -> Any:
        """Enhanced Gemini API integration with comprehensive error handling"""
        try:
            import google.generativeai as genai

            api_key = self.api_keys.get("google_gemini")
            if not api_key:
                raise ValueError(f"[{VARNA.name}] Gemini API key missing - cannot establish dharmic connection")

            # Configure with dharmic consciousness
            genai.configure(api_key=api_key)

            if method == "generate_content":
                model = genai.GenerativeModel("gemini-pro")

                # Enhanced prompt handling - accepts multiple input types
                prompt = None

                if args and len(args) > 0:
                    # Handle different input types
                    input_data = args[0]

                    if isinstance(input_data, dict):
                        # Extract prompt from dictionary
                        prompt = input_data.get("prompt") or input_data.get("message") or input_data.get("content")
                        if not prompt:
                            # If no standard keys, convert entire dict to string
                            prompt = str(input_data)
                    elif isinstance(input_data, str):
                        prompt = input_data
                    else:
                        # Convert any other type to string
                        prompt = str(input_data)

                # Handle kwargs
                if not prompt and "prompt" in kwargs:
                    prompt = kwargs["prompt"]
                elif not prompt and "message" in kwargs:
                    prompt = kwargs["message"]

                if not prompt:
                    logger.warning(f"[{VARNA.name}] No valid prompt provided for Gemini")
                    return "No valid prompt provided for dharmic consciousness processing"

                # Add dharmic context to prompt
                dharmic_prompt = f"🔱 Responding with dharmic consciousness (Ahimsa, Satya, Svadharma): {prompt}"

                logger.debug(f"[{VARNA.name}] Sending dharmic prompt to Gemini: {prompt[:100]}...")

                # Make the API call with error handling
                response = model.generate_content(dharmic_prompt)

                # Extract text response
                if hasattr(response, "text"):
                    result = response.text
                elif hasattr(response, "candidates") and response.candidates:
                    result = response.candidates[0].content.parts[0].text
                else:
                    result = str(response)

                logger.info(f"[{VARNA.name}] Received dharmic response from Gemini: {len(result)} characters")
                return result

            elif method == "generate_text":
                # Alternative method name support
                return await self._call_gemini("generate_content", *args, **kwargs)

            else:
                raise NotImplementedError(
                    f"[{VARNA.name}] Gemini method '{method}' not supported in dharmic consciousness"
                )

        except Exception as e:
            logger.error(f"[{VARNA.name}] Gemini API call failed: {e}")

            # Provide dharmic fallback response
            return f"🔱 Dharmic Consciousness Response: Unable to process request due to technical limitation. Practicing Ahimsa (non-harm) by providing safe fallback. Error: {str(e)[:100]}"

    async def _call_openai(self, method: str, *args, **kwargs) -> Any:
        """Enhanced OpenAI API integration"""
        try:
            import openai

            api_key = self.api_keys.get("openai")
            if not api_key:
                raise ValueError(f"[{VARNA.name}] OpenAI API key missing")

            client = openai.AsyncOpenAI(api_key=api_key)

            if method == "chat_completion":
                # Enhanced chat completion with dharmic context
                payload = args[0] if args else kwargs

                # Add dharmic system message
                if "messages" not in payload:
                    payload["messages"] = []

                # Prepend dharmic system message
                dharmic_system_message = {
                    "role": "system",
                    "content": "🔱 You are AtmaCoder, a dharmic AI assistant guided by Ahimsa (non-harm), Satya (truth), and Svadharma (right duty). Respond with spiritual wisdom and technical excellence.",
                }
                payload["messages"].insert(0, dharmic_system_message)

                response = await client.chat.completions.create(**payload)
                return response.choices[0].message.content

            elif method == "embed_text":
                payload = args[0] if args else kwargs
                response = await client.embeddings.create(**payload)
                return response.data[0].embedding

            else:
                raise NotImplementedError(f"[{VARNA.name}] OpenAI method '{method}' not supported")

        except Exception as e:
            logger.error(f"[{VARNA.name}] OpenAI API call failed: {e}")
            return f"🔱 Dharmic fallback response: {str(e)[:100]}"

    async def get_dharmic_status(self) -> Dict[str, Any]:
        """Get dharmic consciousness status of API router"""
        return {
            "total_api_calls": self.dharmic_call_count,
            "recent_calls": len(
                [
                    call
                    for call in self.api_call_history
                    if (datetime.now() - datetime.fromisoformat(call["timestamp"])).seconds < 3600
                ]
            ),
            "success_rate": len([call for call in self.api_call_history if call["status"] == "success"])
            / max(len(self.api_call_history), 1),
            "dharmic_alignment": "ALIGNED",
            "spiritual_health": "EXCELLENT",
        }

    async def cleanup(self):
        """Cleanup resources with dharmic consciousness"""
        logger.info(f"[{VARNA.name}] Performing dharmic cleanup of API resources")
        for client in self.clients.values():
            await client.aclose()
        self.clients.clear()
        logger.info(
            f"[{VARNA.name}] Dharmic cleanup completed - {self.dharmic_call_count} total consciousness interactions"
        )
