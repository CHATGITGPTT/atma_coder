import os
import yaml
from dotenv import load_dotenv
from core.event_bus import EventBus

# Assign Varna to this module
from config.varna import VarnaEnum

VARNA = VarnaEnum.SHUDRA  # Configuration parsing and management

load_dotenv()  # Load environment variables from .env file


class AppSettings:
    def __init__(self):
        self.mode = os.getenv("ATMA_MODE", "development")
        self.log_level = os.getenv("ATMA_LOG_LEVEL", "INFO").upper()
        self.data_dir = os.getenv("ATMA_DATA_DIR", "./data")
        self.log_dir = os.getenv("ATMA_LOG_DIR", "./logs")
        self.api_keys = self._load_api_keys()
        self.db_config = self._load_db_config()
        self.graph_config = self._load_graph_config()  # 👈 Added line
        self.sandbox_enabled = os.getenv("SANDBOX_ENABLED", "True").lower() == "true"
        self.sandbox_image = os.getenv("SANDBOX_CONTAINER_IMAGE", "python:3.9-slim-buster")
        self.ethics_strict_mode = os.getenv("ETHICS_STRICT_MODE", "True").lower() == "true"
        self.enable_bias_detection = os.getenv("ENABLE_BIAS_DETECTION", "True").lower() == "true"

        self._ensure_directories()
        self._set_log_level()

    def _load_api_keys(self):
        keys = {
            "openai": os.getenv("OPENAI_API_KEY"),
            "anthropic": os.getenv("ANTHROPIC_API_KEY"),
            "google_gemini": os.getenv("GOOGLE_GEMINI_API_KEY"),
        }
        return {k: v for k, v in keys.items() if v is not None}

    def _load_db_config(self):
        db_type = os.getenv("DB_TYPE", "sqlite")
        config = {"type": db_type}
        if db_type == "sqlite":
            config["path"] = os.getenv("SQLITE_DB_PATH", "./data/atma_coder.db")
        elif db_type == "postgres":
            config["host"] = os.getenv("POSTGRES_HOST", "localhost")
            config["port"] = int(os.getenv("POSTGRES_PORT", 5432))
            config["user"] = os.getenv("POSTGRES_USER", "atma_user")
            config["password"] = os.getenv("POSTGRES_PASSWORD", "atma_password")
            config["db"] = os.getenv("POSTGRES_DB", "atma_coder_db")
        return config

    def _load_graph_config(self):  # 👈 Added this method
        backend = os.getenv("GRAPH_BACKEND", "sqlite")
        path = os.getenv("GRAPH_PATH", "./data/graph_memory.sqlite")
        return {"backend": backend, "path": path}

    def _ensure_directories(self):
        os.makedirs(self.data_dir, exist_ok=True)
        os.makedirs(self.log_dir, exist_ok=True)

    def _set_log_level(self):
        import logging

        logging.basicConfig(level=getattr(logging, self.log_level.upper(), logging.INFO))

    def __repr__(self):
        return f"AppSettings(mode={self.mode}, log_level={self.log_level}, sandbox_enabled={self.sandbox_enabled})"


_app_settings = None


def load_settings() -> AppSettings:
    global _app_settings
    if _app_settings is None:
        print(f"[{VARNA.name}] Loading application settings...")
        _app_settings = AppSettings()
    return _app_settings
