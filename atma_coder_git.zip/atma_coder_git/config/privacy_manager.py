# Assign Varna to this module
from config.varna import VarnaEnum

VARNA = VarnaEnum.KSHATRIYA  # Protecting user data, enforcing privacy rules


class PrivacyManager:
    """
    Manages data privacy, ensuring user data is handled according to
    defined policies and ethical guidelines (Ahimsa principle).
    """

    def __init__(self, settings):
        self.settings = settings
        self.privacy_policy_version = "1.0"
        self.sensitive_data_patterns = [
            r"\b(\d{3}[-.\s]?\d{3}[-.\s]?\d{4})\b",  # Phone numbers
            r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",  # Email addresses
            r"\b(?:\d{4}[- ]){3}\d{4}\b",  # Credit card numbers (basic pattern)
            r"SSN:\s*\d{3}[- ]?\d{2}[- ]?\d{4}",  # Social Security Numbers
            # TODO: Add more sophisticated PII/PHI patterns
        ]
        print(f"[{VARNA.name}] PrivacyManager initialized. Policy Version: {self.privacy_policy_version}")

    async def check_data_for_pii(self, data: str) -> bool:
        """
        Asynchronously checks if the given data contains Personally Identifiable Information (PII).
        This is a heuristic check and may not catch all PII.
        """
        import re

        for pattern in self.sensitive_data_patterns:
            if re.search(pattern, data):
                print(f"[{VARNA.name}] PII pattern detected in data. Caution advised.")
                return True
        return False

    async def anonymize_data(self, data: str) -> str:
        """
        Asynchronously attempts to anonymize sensitive data.
        Currently a placeholder for more advanced sanitization.
        """
        # This is a very basic placeholder. A real system would use tokenization,
        # generalization, or differential privacy techniques.
        print(f"[{VARNA.name}] Attempting to anonymize data (placeholder operation).")
        # Replace detected patterns with placeholders
        anonymized_data = data
        for pattern in self.sensitive_data_patterns:
            anonymized_data = re.sub(pattern, "[ANONYMIZED]", anonymized_data)
        return anonymized_data

    async def enforce_data_retention(self, data_path: str, retention_days: int):
        """
        Asynchronously enforces data retention policies for files.
        Removes files older than `retention_days`.
        """
        import os
        import time
        from datetime import datetime, timedelta

        print(f"[{VARNA.name}] Enforcing data retention for: {data_path} (retention: {retention_days} days)")
        if not os.path.exists(data_path):
            print(f"[{VARNA.name}] Data path does not exist: {data_path}")
            return

        current_time = datetime.now()
        cutoff_time = current_time - timedelta(days=retention_days)

        if os.path.isfile(data_path):
            file_mtime = datetime.fromtimestamp(os.path.getmtime(data_path))
            if file_mtime < cutoff_time:
                print(f"[{VARNA.name}] Deleting old file: {data_path} (last modified: {file_mtime})")
                os.remove(data_path)
            return

        if os.path.isdir(data_path):
            for root, _, files in os.walk(data_path):
                for file_name in files:
                    file_path = os.path.join(root, file_name)
                    try:
                        file_mtime = datetime.fromtimestamp(os.path.getmtime(file_path))
                        if file_mtime < cutoff_time:
                            print(f"[{VARNA.name}] Deleting old file: {file_path} (last modified: {file_mtime})")
                            os.remove(file_path)
                    except OSError as e:
                        print(f"[{VARNA.name}] Error processing file {file_path}: {e}")
