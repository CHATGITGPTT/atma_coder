# config/runtime_config.py

runtime_config = {"current_model": "Gemini"}


def set_model(model_name):
    runtime_config["current_model"] = model_name


def get_model():
    return runtime_config["current_model"]
