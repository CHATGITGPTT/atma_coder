from enum import Enum

# Assign Varna to this module - special case, this defines Varna itself.
# Conceptually it's BRAHMAN-like for defining truth, but SHUDRA-like for being foundational infra.
# Let's say BRAHMAN for its definitional quality.
VARNA_SELF_ASSIGN = "BRAHMAN"  # Self-assignment for the Varna definition file itself.


class VarnaEnum(Enum):
    """
    Enumeration representing the Varna system for internal module classification.
    Each module and class in atma_coder is assigned a Varna to guide its behavior
    and responsibilities.
    """

    BRAHMAN = "BRAHMAN"  # Intelligence, truth-checking, long-term vision, core philosophy
    KSHATRIYA = "KSHATRIYA"  # Protection, ethics enforcement, security, refusal logic
    VAISHYA = "VAISHYA"  # Tool building, workflow management, resource allocation, productivity
    SHUDRA = "SHUDRA"  # Infrastructure maintenance, foundational services, data handling, sandbox

    def __str__(self):
        return self.value

    def get_description(self):
        """Provides a brief description for each Varna."""
        if self == VarnaEnum.BRAHMAN:
            return "Handles intelligence, truth-checking, long-term vision, core philosophy."
        elif self == VarnaEnum.KSHATRIYA:
            return "Protects structure, enforces ethics, stops misuse."
        elif self == VarnaEnum.VAISHYA:
            return "Builds tools, workflows, enables structured productivity."
        elif self == VarnaEnum.SHUDRA:
            return "Maintains infrastructure, watches files, handles sandboxes."
        else:
            return "Undefined Varna."
