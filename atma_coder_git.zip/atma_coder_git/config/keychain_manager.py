import os

import keyring

from config.varna import VarnaEnum

# Assign Varna to this module
VARNA = VarnaEnum.KSHATRIYA  # Secure handling of credentials


class KeychainManager:
    """
    Handles secure storage and retrieval of secrets using the system keychain.
    Uses `keyring` library which delegates to OS-native secure credential store.
    """

    def __init__(self, service_name="atma_coder"):
        self.service_name = service_name
        print(f"[{VARNA.name}] KeychainManager initialized for service: {self.service_name}")

    def store_api_key(self, key_name: str, api_key: str):
        """
        Stores an API key securely.
        """
        keyring.set_password(self.service_name, key_name, api_key)
        print(f"[{VARNA.name}] API key stored securely for: {key_name}")

    def get_api_key(self, key_name: str) -> str:
        """
        Retrieves an API key securely.
        """
        api_key = keyring.get_password(self.service_name, key_name)
        if api_key:
            print(f"[{VARNA.name}] Retrieved API key for: {key_name}")
        else:
            print(f"[{VARNA.name}] No API key found for: {key_name}")
        return api_key

    def delete_api_key(self, key_name: str):
        """
        Deletes a stored API key.
        """
        keyring.delete_password(self.service_name, key_name)
        print(f"[{VARNA.name}] Deleted API key for: {key_name}")
